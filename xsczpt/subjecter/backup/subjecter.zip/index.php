<?php
	/* ��Уѧ�ƿռ�*/
	header("Content-type: text/html; charset=gbk;");
	require('../ppf/fun.php');
	require('../ppf/pdo_mysql.php');
	require("../ppf/pdo_template.php");
	require("./srv/func.php");
	
	$qname = isset($_GET["t"]) ? $_GET["t"] : "index";
	$tplName = get_tplName();				// ģ������
	
	# ����½
	if (!session_id()) session_start();
	$uid = isset($_SESSION['uid']) ? $_SESSION['uid'] : "";		// �û�ID

	$T = new pdo_template('html/'.$tplName.'/'.$qname.'.htm');
	$subjecterId = getSubjecterId($T);		// ��ѧ��ID
	$T->SetTpl('cssjs' , 'html/public/cssjs_bt.inc');
	$T->SetTpl('top' , '../inc/top.htm');
	$T->SetTpl('foot' , '../inc/foot.htm');
	$T->SetTpl('head', get_head_file($tplName, $qname, $subjecterId));	// ������
	$T->Set($qname, 'active');				// ��������ǰҳѡ�е���ʽ
	
	if(!empty($uid)){
		# ���ɺ�̨����������
		showAdminRoles($uid, 'bask', 'admin', $T);
	}
	$pagesize = 15;

	switch($qname){
		
		case "index": 		## ��ҳ
			$noticeId = getNoticeId($T);
			load_articles($noticeId, $T);
			load_slides($subjecterId, $tplName, $T);
			load_template($subjecterId, $qname, $tplName, $noticeId, $T);
			
		case "articles":	## ѧ�����·��༰�б�
			$T->SetBlock("cate", "select * from subjecter_article_type order by odx");
			
			# �״μ���ʱĬ�Ϸ�ҳ��ʾ���з����µ�����
			$typeid = isset($_GET["typeid"]) ? $_GET["typeid"] : "";
			$T->Set('chs_typeid'.$typeid, 'style="color:white; background-color:#63ACF4;"');	// ѡ�з���Ĳ˵���ʽ
			
			if($typeid != "") {
				$T->Set("typename", $T->query("select name from subjecter_article_type where id=".$typeid)->fetchColumn(0));
			} else {
				$T->Set("typename", ">>��������");
			}
			
			$srcsql = " where A.state=2 and t6.display=1 and t4.school=0";	// ѧ�����á�ѧ��school�ֶ�Ϊ0
			if(!empty($typeid)) $srcsql.=" and A.typeid=".$typeid." ";  
			
			$p = isset($_GET["p"])?$_GET["p"]:"1";
			
			$rc = $T->db->query(
				@"select count(1) from subjecter_articles A 
				left join sys_subject t4 on t4.id=A.subject 
				left join sys_period t6 on t6.id=A.period ".$srcsql)->fetchColumn(0);
			if($rc > $pagesize) {
				$page = getPageHtml_bt($rc, $pagesize, $p, "&t=articles&typeid=".$typeid);
				$T->Set("page",$page); 
			}
			
			$T->Mual_SetBlock('list',
				@"select A.*,M.nick as nickname, S.id as schoolid, S.name as schoolname, A.postdate,
				(select count(1) from subjecter_comments C where C.artid=A.id) as comms 
				from subjecter_articles A 
				left join act_member M on A.uid=M.id 
				left join school S on S.id=M.school 
				left join sys_subject t4 on t4.id=A.subject 
				left join sys_period t6 on t6.id=A.period"
				.$srcsql." order by A.postdate desc limit ".(($p-1)*$pagesize).",$pagesize");
				
			$tmp = "";
			if($T->m_rs){
				while ($r = $T->m_rs->fetch(PDO::FETCH_ASSOC)) {
					$tmp = trimall(strip_tags($r['content']));
					$T->Mual_Assign("content", "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".(isset($tmp{200}) ? (substr($tmp, 0, 200)."...") : $tmp));
					$T->Mual_Full($r);
					$T->Mual_OneBlock();
				}
				$T->Mual_EndBlock();
			}
			break;
		case "article":	## ����չʾҳ
			if (!session_id()) session_start();
			$uid = isset($_SESSION['uid']) ? $_SESSION['uid'] : "";	// ��ǰ��½�û�
			$T->Set("uid", $uid);
			
			$artSql = "select A.*, M.nick as nickname, SC.id as schoolid,";
			$artSql .= " SC.name as schoolname, T.name as typeName";
			$artSql .= " from `subjecter_articles` A";
			$artSql .= " left join act_member M on A.uid=M.id";
			$artSql .= " left join subjecter_article_type T on A.typeid=T.id";
			$artSql .= " left join school SC on SC.id=M.school";
			$artSql .= " where A.id=".$_GET["id"];
			$T->readDB($artSql);
			
			$commentSql = "";
			if($uid != "") {
				$commentSql = "select A.*, M.nick as nickname, A.id as cmtid, if(A.uid='".$uid."','<a onclick=delcomment(this)>ɾ��</a>','') as delstate from `subjecter_comments` A left join act_member M on A.uid=M.id where A.artid=".$_GET["id"]." order by id desc";
			} else {
				$commentSql = "select A.*,M.nick as nickname,A.id as cmtid from `subjecter_comments` A left join act_member M on A.uid=M.id where A.artid=".$_GET["id"]." order by id desc";
			}
			$T->SetBlock("list", $commentSql);
			break;
			
		case "resources":	# ��Դ���ͼ�չʾҳ			
			$searchArray = array(
				'restype'=>isset($_GET["tp"]) ? $_GET["tp"] : "",
				'period'=>isset($_GET["per"]) ? $_GET["per"] : "",
				'subject'=>isset($_GET["s"]) ? $_GET["s"] : "",
				'grade'=>isset($_GET["g"]) ? $_GET["g"] : "",
				'book'=>isset($_GET["b"]) ? $_GET["b"] : "",
				'chapter'=>isset($_GET["c"]) ? $_GET["c"] : "",
				'part'=>isset($_GET["pt"]) ? $_GET["pt"] : "",
				'edition'=>isset($_GET["e"]) ? $_GET["e"] : "",
				'volume'=>isset($_GET["v"]) ? $_GET["v"] : "",
				'year'=>isset($_GET["y"]) ? $_GET["y"] : "",
				'required'=>isset($_GET["r"]) ? $_GET["r"] : ""
			);
			
			$T->SetBlock2("list_period", getQueryPeriodSql(1),
				array(array("block"=>"list_period_rp", "pid"=>"id", "sql"=>"select id,name,period from sys_subject where school=0 and period=? order by odx")));
			
			$href = "";	// ������ǩ��ʾ������
			
			if($searchArray['subject'] != "") {
				$T->SetBlock("list_grade", "select * from sys_grade where period=".$searchArray['period']);
				
				$href = "?t=resources&per=".$searchArray['period']."&s=".$searchArray['subject'];
				$T->Set("grade_href", $href);
			}
			
			if($searchArray['period'] != "" && $searchArray['subject'] != "" && $searchArray['grade'] != "") {
				$T->SetBlock("list_book", "select * from sys_textbook where period=".$searchArray['period']." and subject=".$searchArray['subject']." and grade=".$searchArray['grade']);
				
				$href = "?t=resources&per=".$searchArray['period']."&s=".$searchArray['subject']."&g=".$searchArray['grade'];
				$T->Set("book_href", $href);
			}
			
			if($searchArray['book'] != "") {
				$T->SetBlock2("list_chapters", 
				@"SELECT id,title,odx from sys_books_chapters where parentid=0 and book=".$searchArray['book']." order by odx",
				array(array("block"=>"list_chapters_rp", "pid"=>"id", "sql"=>"select id,title,odx from sys_books_chapters where parentid=? order by odx")));
				
				$href = "?t=resources&per=".$searchArray['period']."&s=".$searchArray['subject']."&g=".$searchArray['grade']."&b=".$searchArray['book'];
				$T->Set("chapter_href", $href);
				$T->Set("part_href", $href);
			}
			
			if($searchArray['chapter'] != "") {
				$href = "?t=resources&per=".$searchArray['period']."&s=".$searchArray['subject']."&g=".$searchArray['grade']."&b=".$searchArray['book']."&c=".$searchArray['chapter'];
			} else if ($searchArray['part'] != "") {
				$href = "?t=resources&per=".$searchArray['period']."&s=".$searchArray['subject']."&g=".$searchArray['grade']."&b=".$searchArray['book']."&pt=".$searchArray['part'];
			}
			
			if($searchArray['restype'] != "") {
				$href .= "&tp=".$searchArray['restype'];
			}
			
			if($searchArray['edition'] != "") {
				$href .= "&e=".$searchArray['edition'];
			}
			
			if($searchArray['volume'] != "") {
				$href .= "&v=".$searchArray['volume'];
			}
			
			if($searchArray['required'] != "") {
				$href .= "&r=".$searchArray['required'];
			}
			
			if($searchArray['year'] != "") {
				$href .= "&y=".$searchArray['year'];
			}
			
			if(!strpos($href, 'resources')) {
				$href = '?t=resources'.$href;
			}
			
			initLinks("restype_link", 'res_type', 'tp', str_replace("&tp=".$searchArray['restype'], '', $href), $T);
			initLinks("edition_link", 'sys_textbook_edition', 'e', str_replace("&e=".$searchArray['edition'], '', $href), $T);
			initLinks("volume_link", 'sys_textbook_volume', 'v', str_replace("&v=".$searchArray['volume'], '', $href), $T);
			initRequiredLinks("required_link", str_replace("&r=".$searchArray['required'], '', $href), $T);
			initYearLinks("year_link", str_replace("&y=".$searchArray['year'], '', $href), $T);
			
			$srcSql = getSearchSql('R', $searchArray);
			
			$p = isset($_GET["p"]) ? $_GET["p"] : "1";
			
			$rc = $T->db->query(
				@"select count(1) from subjecter_resources R 
				left join sys_subject S on S.id=R.subject 
				left join sys_period P on P.id=R.period 
				where R.state=2 and S.school=0 and P.display=1 ".$srcSql)->fetchColumn(0);
			if($rc > $pagesize) {
				$page = getPageHtml_bt($rc, $pagesize, $p, "&".str_replace('p='.$p.'&', '', $_SERVER['QUERY_STRING']));
				$T->Set("page",$page);
			}
			
			$sql = @"select R.*, M.truename, SCH.name as school_name, T.name as restype_name, 
					P.name as period_name, S.name as sub_name, G.name as grade_name,
					BOOK.title as book_name, CHA.title as chapter_name, PAR.title as part_name,
					E.name as edition_name, V.name as volume_name
					
					from subjecter_resources R 
					
					left join act_member M on M.id=R.uid 
					left join school SCH on SCH.id=M.school 
					left join res_type T on T.id=R.restype 
					
					left join sys_period P on P.id=R.period 
					left join sys_subject S on S.id=R.subject 
					left join sys_grade G on G.id=R.grade 
					
					left join sys_textbook BOOK on BOOK.id=R.book 
					left join sys_books_chapters CHA on CHA.id=R.chapter 
					left join sys_books_chapters PAR on PAR.id=R.part
					
					left join sys_textbook_edition E on E.id=R.edition  
					left join sys_textbook_volume V on V.id=R.volume  
					where R.id>0 and R.state=2 and S.school=0 and P.display=1 ".$srcSql
					." order by id desc limit ".(($p - 1) * $pagesize).",$pagesize";
					
			$T->SetBlock("list_resources", $sql);
			break;
			
		case "res_view":
			$period = isset($_GET["per"]) ? $_GET["per"] : "";
			$subject = isset($_GET["s"]) ? $_GET["s"] : "";
			
			$T->Set("period_name", $T->query("select `name` from sys_period where display=1 and id=$period")->fetchColumn(0));
			$T->Set("subject_name", $T->query("select `name` from sys_subject where school=0 and id=$subject")->fetchColumn(0));
			break;
	}

	$T->Set('tplno', $tplName);
	$T->Set("gtitle",LR_NAME);
	$T->clearNaN();
	$T->clearNoN();
	$T->display();
	$T->close();
	unset($T);
	