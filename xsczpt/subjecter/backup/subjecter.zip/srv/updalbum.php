<?php 
#header("Content-type: text/html; charset=gbk;");
require '../../cfg/config.inc';
/*上传照片*/
#检测登录

foreach($_FILES as $f) 
{ //if (function_exists("iconv"))$f["name"] = iconv("UTF-8","GB2312",$f["name"]);	
	if ($f["error"] > 0){
		echo '{"ret":"err","errno":"1","des":"'. urlencode("文件出错").'"}';
		exit();
	}
	$fsize=$f["size"]; #($f["size"] / 1024) . kb;
	$ftmp_name=$f["tmp_name"];//临时文件位置  $_files["file"]["tmp_name"];
	$ftype=$f["type"];//文件类型 $_files["file"]["type"]
	$fname=$f["name"];  //原始文件名 $_files["file"]["name"]
  
	$fext=".".strtolower(pathinfo($fname, PATHINFO_EXTENSION));
  $ofname=basename($fname,$fext);
	if(!strpos(" .jpg.gif.png.bmp",$fext)){
		echo '{"ret":"err","errno":"5","des":"'. urlencode("禁止上传的文件类型").'"}';
		exit();
	}
	
  $dir=DIR_ROOT.UP_FILE.$_GET["f"]."/album/";
	$y=date("Y");	 #/m/d
	$d=date("z");
	$w=ceil($d/7);
	$fd=$dir.$y."/".$w."/";  #以每周为单位
	if(!is_dir($fd)){
		$re=mkdir($fd,0777,true);#第3个参数为创建多级目录
		if(!$re){
			echo '{"ret":"err","des":"'. urlencode("创建目录错误，没有权限").'"}';
			exit();
		}
	}	
	$nname=microtime(true); #毫秒#time().
	//保存文件 
	if (move_uploaded_file($ftmp_name, $fd.$nname.$fext)){  
		echo '{"ret":"ok","flag":"'.$_GET["flag"].'","fname":"'.$y."/".$w."/".$nname.$fext.'","ofname":"'.$ofname.'"}';	
	}
}