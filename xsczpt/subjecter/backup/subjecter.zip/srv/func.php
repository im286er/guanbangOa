<?php
	require_once '../ppf/pdo_mysql.php';
	
	# PHPȥ���ַ����е����пո񼰻���
	function trimall($str){
		//$str = trim($str);
		//$str = preg_replace('/[\s��]/', '', $str);
		return str_replace(array(" ","��","\t","\n","\r"), '', $str);
	}
	
	# ���ز�ѯ����ѧ�ε�sql
	function getQueryPeriodSql($display=1) {
		$sql = $display == 1 ? " where display=1 " : "";
		return "select * from `sys_period` ".$sql." order by odx";
	}
	
	# ����ǰ��ģ������
	function get_tplName() {
		$pd = new pdo_mysql();
		$tmp = $pd->query('select template from subjecter where parentid=0')->fetchColumn(0);
		$pd->close();
		unset($pd);
		return $tmp;
	}
	
	# ��̬���ɹ���Ȩ�޵����
	function showAdminRoles($uid, $type, $tag, $T) {
		switch($type) {
			case "bask":	# ��̨�������
				$isAdmin = $T->query("select * from main_member where uid='".$uid."'")->fetchColumn(0);
				if($isAdmin) {$T->Set($tag, '<li class="nav_menu-item"><a href="man" target="_blank">����</a></li>');}
				break;
			case "":
				// others
				break;
		}
	}
	
	# ������Դ������ǩ�����棩
	function get_head_file($tplName, $qname, $subjecterId) {
		
		if(!file_exists('html/'.$tplName.'/head.htm')) {
			
			$T = new pdo_template('html/'.$tplName.'/tpl_head.htm');
			$content = "";
			
			switch($tplName) {
				case "1":
					$T->SetBlock2("list_res", getQueryPeriodSql(1),
						array(array("block"=>"rp", "pid"=>"id", "sql"=>"select id,name,period from sys_subject where school=0 and period=? order by odx")));
					break;
					
				case "2":
					// TODO
					break;
			}
			
			$T->readDB("select id, title as banner_title, des, pic, picname, url, parentid, template from subjecter where id=".$subjecterId);		// ��ҳ������Ϣ��ʼ��
			
			//����{}��ǩ�����ͳһ�滻
			//$T->clearNaN();
			//$T->clearNoN(); 
			
			$content = $T->content;
			$T->close();
			unset($T);
			file_put_contents('html/'.$tplName.'/head.htm', $content);
		}
		return 'html/'.$tplName.'/head.htm';
	}
	
	# ������ѧ�ƿռ��¼��id
	function getSubjecterId($T) {
		return $T->query("select * from subjecter where parentid=0")->fetchColumn(0);
	}
	
	# ����֪ͨ����ķ���id
	function getNoticeId($T) {
		return $T->query("select id from subjecter_article_type where name='֪ͨ����'")->fetchColumn(0);
	}
	
	# ��ʾ֪ͨ���沿��
	function load_articles($noticeId, $T) {
		$T->Set("noticeId", empty($noticeId) ? 0 : $noticeId);
		
		## ֪ͨ����
		if(!empty($noticeId)) {
			$T->Mual_SetBlock("list_notice", "select (@i:=@i+1) as row_no, id, title, postdate from subjecter_articles,(select @i:=0) as tmp where typeid=".$noticeId." order by id desc limit 0,10");
			$tmp = 0;
			if($T->m_rs){
				while ($r = $T->m_rs->fetch(PDO::FETCH_ASSOC)) {
					$tmp = intval(trimall(strip_tags($r['row_no'])));
					# ֪ͨ���������ʾ��ʽ����
					$T->Mual_Assign("row_no", $tmp > 3 ? "<em class='rNum'>".$tmp."</em>" : "<em class='rNum hotbg'>".$tmp."</em>");
					$T->Mual_Full($r);
					$T->Mual_OneBlock();
				}
				$T->Mual_EndBlock();
			}
		}
		
		## ֪ͨ����
		$hasNotice = empty($noticeId) ? "" : " where A.typeid!=".$noticeId;
		$srcSql = "select A.id,A.title,A.postdate,M.nick as nickname,S.name as schoolname from subjecter_articles A";
		$srcSql .= " left join act_member M on A.uid=M.id";
		$srcSql .= " left join school S on S.id=M.school";
		$srcSql .= $hasNotice;
		
		## ���·���
		$T->SetBlock("list_new", $srcSql." order by A.postdate desc limit 0,10");
		
		## �ȵ㾫Ʒ�����������ࣩ
		$T->SetBlock("list_hot", $srcSql." order by A.visit desc limit 0,10");
	}
	
	# ���ػõ�Ƭ
	function load_slides($subjecterId, $tplName, $T) {
		## �õ�Ƭ
		$T->Mual_SetBlock("list_slides", "select * from subjecter where parentid=".$subjecterId." and template='".$tplName."' order by odx"); 
		$tmp = "";
		if($T->m_rs){
			while ($r = $T->m_rs->fetch(PDO::FETCH_ASSOC)) {
				$tmp = trimall(strip_tags($r['pic']));
				$T->Mual_Assign("pic", str_replace('../', '', $tmp));
				$T->Mual_Full($r);
				$T->Mual_OneBlock();
			}
			$T->Mual_EndBlock();
		}
	}
	
	## ģ��2�������ã��˴������ݲ�ɾ��
	function load_template($subjecterId, $qname, $tplName, $noticeId, $T) {
		
		switch($tplName) {
			case '01':
				
				break;
			case '02':
			
				## ѧ�Ρ��꼶
				$T->SetBlock("list_period", getQueryPeriodSql(1));
				
				# ��Ʒ��Դ����
				$resSql = "select R.*, M.nick as nickname, S.name as schoolname from sub_resources R";
				$resSql .= " left join act_member M on R.uid=M.id";
				$resSql .= " left join school S on S.id=M.school";
				$resSql .= " order by R.postdate desc limit 12";
				$T->SetBlock("list_resources", $resSql);
				
				## ѧ��
				$T->SetBlock("list_subject", "select id,name from sys_subject");
				$T->SetBlock("list_subject2", "select id,name from sys_subject");
				
				## ��Ʒ���¼���
				$subject = isset($_GET["sjt"]) ? $_GET["sjt"] : "";
				$T->Set("list_articles", getArtItems(empty($noticeId) ? 0 : $noticeId, $subject, $T));
				break;
		}
	}
	
	# ������ҳ�������б�
	function getArtItems($noticeid, $subject, $T) {
		$html = "";
		
		$subjectSql = "select id,title,date(postdate) as postdate, original from subjecter_articles where typeid=:typeid order by id desc limit 8";
		if(!empty($subject)) {
			$subjectSql = "select id,title,date(postdate) as postdate, original from subjecter_articles where typeid=:typeid and subject=".$subject." order by id desc limit 8";
		}
		
		$result = $T->query("select * from subjecter_article_type where `id`!=".$noticeid." order by odx")->fetchAll(PDO::FETCH_ASSOC);
		
		$hr = 0;	// ��
		$rowCount = count($result);		// ��Ԫ�ظ���
		
		foreach($result as $row) {
			$hr += 1;
			$html .= '<div class="col-triple">';
			$html .= '<div class="col-box">';
			$html .= '<div class="col-header">';
			$html .= '<label>'.$row['name'].'</label>';
			$html .= '<a class="more" target="_blank" href="?t=articles&typeid='.$row['id'].'">More&gt;&gt;</a>';
			$html .= '</div>';
			$html .= '<ul class="list">';
			
			// ѭ������<li>
			$articles = $T->db->prepare($subjectSql);
			$articles->bindParam(':typeid', $row['id']);
			$articles->execute();
			$j = 1;
			while( $res = $articles->fetch(PDO::FETCH_ASSOC) ) {
					$html .= '<li>';
					$html .= '<a title="'.$res['title'].'" target="_blank" href="./?t=article&id='.$res['id'].'" class="main-title"> ['.($res['original'] == 1 ? "ԭ��" : "ת��").'] '.$res['title'].'</a>';
					$html .= '<span class="note">'.$res['postdate'].'</span>';
					$html .= '</li>';
					$j += 1;
			}
			
			while($j <= 8) {
				$html .= '<li>&nbsp;</li>';
				$j += 1;
			}
			
			$html .= '</ul>';
			$html .= '</div>';
			$html .= '</div>';
			
			if($hr%3 == 0 && $hr != $rowCount){
				$html .= '<div class="cols clearfix"><div class="col-double"><ul class="list"><li></li></ul></div></div>';
			}
		}
		
		return $html;
	}
	
	# ������Դ�������Ա�ǩ��html����
	function initLinks($tag, $tablename, $queryString, $href, $T) {
		$data = isset($_GET[$queryString]) ? $_GET[$queryString] : "";
		
		$stmt = $T->query("SELECT * from ".$tablename." order by odx")->fetchAll(PDO::FETCH_ASSOC);
		$html = '<a href="'.$href.'" '.($data == "" ? 'class="hs_on"' : '').'">ȫ��</a>';
		
		foreach($stmt as $row) {
			$html .= '<a href="'.$href.'&'.$queryString.'='.$row['id'].'" '.($data == $row['id'] ? 'class="hs_on"' : '').'>'.$row['name'].'</a>';
		}
		
		$T->Set($tag, $html);
	}
	
	# �������
	function initYearLinks($tag, $href, $T) {
		$year = isset($_GET["y"]) ? $_GET["y"] : "";
		
		$stmt = $T->query("SELECT distinct(year) from subjecter_resources where year is not null order by year")->fetchAll(PDO::FETCH_ASSOC);
		$html = '<a href="'.$href.'" '.($year == "" ? 'class="hs_on"' : '').'>ȫ��</a>';
		
		foreach($stmt as $row) {
			$html .= '<a href="'.$href.'&y='.$row['year'].'" '.($year == $row['year'] ? 'class="hs_on"' : '').'>'.$row['year'].'</a>';
		}
		
		$T->Set($tag, $html);
	}
	
	# ����ѡ���޵�<a>��ǩ
	function initRequiredLinks($tag, $href, $T) {
		$required = isset($_GET["r"]) ? $_GET["r"] : "";
		$html = '<a href="'.$href.'" '.($required == "" ? 'class="hs_on"' : '').'>ȫ��</a>';
		$html .= '<a href="'.$href.'&r=1" '.($required == 1 ? 'class="hs_on"' : '').'>����</a>';
		$html .= '<a href="'.$href.'&r=2" '.($required == 2 ? 'class="hs_on"' : '').'>ѡ��</a>';
		
		$T->Set($tag, $html);
	}
	
	# ���ز�ѯ������sql��䣬���������ʽΪ �ֶ���=>����ֵ
	function getSearchSql($alias, $searchArray) {
		$srcSql = "";
		
		foreach ($searchArray as $key=>$value) {
			if($value != "") {
				if($key == 'title') {
					$srcSql .= " and {0}.`".$key."` like '%".$value."%'";
				} else {
					$srcSql .= " and {0}.`".$key."`=".$value;
				}
			}
		}
		
		return str_replace('{0}', $alias, $srcSql);
	}