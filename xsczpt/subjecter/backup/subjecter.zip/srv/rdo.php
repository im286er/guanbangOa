﻿<?php 
	header("Content-type: text/html; charset=utf-8;");
	require '../../ppf/fun.php';
	require '../../ppf/pdo_mysql.php';
	require '../man/srv/func.php';

	$pd=new pdo_mysql();

	switch($_POST["tpl"]){
		case "chg_art_by_subject":
			echo getArticleItems($_POST["ntid"] == "" ? 0 : $_POST["ntid"], $_POST["sjt"], $pd);
			break;
		case "chg_res_by_subject":
			echo getResItems($_POST["sjt"], $_POST["gra"], $pd);
			break;
		case "fill_grade":
			echo fillGrade("sys_grade where period=".$_POST["p"], "年级", $pd);
			break;
	}
	
	// 返回年级select标签内容
	function fillGrade($tableName, $defaultName, $T) { 
		$html = '<option value="">'.$defaultName."</option>";
		
		$result = $T->query("select id, name from ".$tableName." order by id")->fetchAll(PDO::FETCH_ASSOC);
		
		foreach($result as $row) {
			$html .= "<option value='".$row['id']."'>".$row['name']."</option>";
		}
		
		return $html;
	}

	// 返回首页的文章列表
	function getArticleItems($noticeId, $subject, $T) {
		$html = "";
		
		$subjectSql = "select id,title,date(postdate) as postdate, original from subjecter_articles where typeid=:typeid order by id desc limit 8";
		if(!empty($subject)) {
			$subjectSql = "select id,title,date(postdate) as postdate, original from subjecter_articles where typeid=:typeid and subject=".$subject." order by id desc limit 8";
		}
		
		$result = $T->query("select * from subjecter_article_type where `id`!=".$noticeId." order by odx")->fetchAll(PDO::FETCH_ASSOC);
		
		$hr = 0;	// 行
		$rowCount = count($result);		// 总元素个数
		
		foreach($result as $row) {
			$hr += 1;
			$html .= '<div class="col-triple">';
			$html .= '<div class="col-box">';
			$html .= '<div class="col-header">';
			$html .= '<label>'.$row['name'].'</label>';
			$html .= '<a class="more" target="_blank" href="?t=articles&typeid='.$row['id'].'">More&gt;&gt;</a>';
			$html .= '</div>';
			$html .= '<ul class="list">';
			
			// 循环生成<li>
			$articles = $T->db->prepare($subjectSql);
			$articles->bindParam(':typeid', $row['id']);
			$articles->execute();
			$j = 1;
			while( $res = $articles->fetch(PDO::FETCH_ASSOC) ) {
					$html .= '<li>';
					$html .= '<a title="'.$res['title'].'" target="_blank" href="./?t=article&id='.$res['id'].'" class="main-title"> ['.($res['original'] == 1 ? "原创" : "转载").'] '.$res['title'].'</a>';	// .($res['original'] == 1 ? '[原创]' : '[转载]') 乱码
					$html .= '<span class="note">'.$res['postdate'].'</span>';
					$html .= '</li>';
					$j += 1;
			}
			
			while($j <= 8) {
				$html .= '<li>&nbsp;</li>';
				$j += 1;
			}
			
			$html .= '</ul>';
			$html .= '</div>';
			$html .= '</div>';
			
			if($hr%3 == 0 && $hr != $rowCount){
				$html .= '<div class="cols clearfix"><div class="col-double"><ul class="list"><li></li></ul></div></div>';
			}
		}
		
		return $html;
	}
	
	// 返回首页的资源列表
	function getResItems($subject, $grade, $T) {
		$html = "";
		$srcSql = "";
		
		if(!empty($subject)) {
			$srcSql .= " and R.subject=".$subject;
		}
		
		if(!empty($grade)) {
			$srcSql .= " and R.grade=".$grade;
		}
		
		$resSql = "SELECT R.*, M.nick as nickname, S.name as schoolname from sub_resources R";
		$resSql .= " left join act_member M on R.uid=M.id";
		$resSql .= " left join school S on S.id=M.school";
		$resSql .= " where R.id>0";
		$resSql .= $srcSql;
		$resSql .= " order by R.postdate desc limit 12";
		$result = $T->query($resSql)->fetchAll(PDO::FETCH_ASSOC);
		
		foreach($result as $row) {
			$html .= '<li>';
			$html .= '<div class="item">';
			$html .= '<div class="grid-pic">';
			$html .= '<a title="'.$row['title'].'" href="/subject/?t=resource&s='.$row['school'].'&sid='.$row['sid'].'&id='.$row['id'].'" target="_blank">';
			$html .= '<img title="'.$row['title'].'" src="/upds/subject/reslogo/'.$row['reslogo'].'">';
			$html .= '</a>';
			$html .= '</div>';
			$html .= '<div class="grid-desc">';
			$html .= '<a href="/subject/?t=resource&s='.$row['school'].'&sid='.$row['sid'].'&id='.$row['id'].'" target="_blank">';
			$html .= $row['title'];
			$html .= '</a>';
			$html .= '</div>';
			$html .= '<div class="grid-footer"><a href="/zone" target="_blank">'.$row['nickname'].'</a> - <a href="/school?s='.$row['school'].'" target="_blank">'.$row['schoolname'].'</a></div>';
			$html .= '<div class="grid-footer">总浏览：<span class="em">'.$row['visit'].'</span>人</div>';
			$html .= '</div>';
			$html .= '</li>';
		}
		
		return $html;
	}

	$pd->close();
	unset($pd);
	unset($rs);