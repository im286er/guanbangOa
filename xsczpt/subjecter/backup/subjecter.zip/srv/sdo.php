<?php 
/*set do
*/
header("Content-type: text/html; charset=utf-8;"); 
require '../../ppf/fun.php';
require '../../ppf/pdo_mysql.php';

$pd=new pdo_mysql();
switch($_POST["tpl"]){
	case "sbj_vote":	## ��������۵����ӷ��ʴ���������Ϊtablename���ֶ���
		$pd->exec("update `".$_POST["tb"]."` set `".$_POST["col"]."`=ifnull(`".$_POST["col"]."`,0)+1 where id='".$_POST["id"]."'");
		echo "ok";
		break;
	case "add_use":	## ��������
		$pd->exec("update subjecter_comments set `use`=`use`+1 where id=".$_POST["id"]);
		echo "ok";
		break;
	case "add_nouse":	## ����û��
		$pd->exec("update subjecter_comments set `nouse`=`nouse`+1 where id=".$_POST["id"]);
		echo "ok";
		break;
	case "do_comment":	# ��������
		$artId = $_POST["a"];
		$uid = $_POST["u"];
		$content = $_POST["c"];
		$postdate = $_POST["d"];
		$type = $_POST["t"];	// ��������   1 ����   2 ��Դ
		
		$result = $pd->prepare("insert into subjecter_comments (artid, uid, content, postdate, timestamp, type) values (:artid, :uid, :content, :postdate, UNIX_TIMESTAMP(), :type)");
		$result->bindParam(':artid', $artId);
		$result->bindParam(':uid', $uid);
		$result->bindParam(':content', $content);
		$result->bindParam(':postdate', $postdate);
		$result->bindParam(':type', $type);
		$result->execute();
		$insId = $pd->lastInsertId();	// �����������ID
		
		$rs = $pd->query("select id,(select nick from act_member m where m.id=c.uid) as nickname,postdate,content from subjecter_comments c where id=".$insId);
		echo json_encode($rs->fetchAll(PDO::FETCH_ASSOC));
		break;
	case "del_comm":	# ɾ������
		$pd->exec("delete from subjecter_comments where id=".$_POST['id']);
		echo "ok";
		break;
}		
$pd->close();
unset($pd);
unset($rs);