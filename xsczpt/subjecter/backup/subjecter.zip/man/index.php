<?php
	/* �������� */
	header("Content-type: text/html; charset=gbk;");
	require('../../ppf/fun.php');
	require('../../ppf/pdo_mysql.php');
	require("../../ppf/pdo_template.php");
	require("./srv/func.php");
	
	$qname = isset($_GET["t"]) ? $_GET["t"] : "index";
	$tplName = get_tplName();	// ģ������
	
	if (!session_id()) session_start();
	chkLogin("uid","/?t=login");	// ����Ƿ��½
	$uid = $_SESSION['uid'];	// �û�ID
	
	$T=new pdo_template('./html/'.$qname.'.htm');
	$T->SetTpl('cssjs','cssjs_bt.inc');
	$T->SetTpl('top','../../inc/top.htm');
	$T->SetTpl('foot','../../inc/foot.htm');
	$T->SetTpl('menu','menu.htm');
	
	# ������Ȩ��
	$isAdmin = $T->query("select * from main_member where uid='".$uid."'")->fetchColumn(0);
	if(!$isAdmin){
		header("location: /?t=error&no=204&name=û�й���Ȩ��&msg=��û�й���Ȩ�ޣ�");
	}
	
	$user_subject = $T->query("select subject from act_member where `id`='$uid'")->fetchColumn(0);
	$user_period = $T->query("select period from sys_subject where `id`=$user_subject")->fetchColumn(0);
	$subjecterId = $T->query("select * from subjecter where parentid=0")->fetchColumn(0);
	$T->Set("sub_title", $T->query("select concat(P.name, S.name) from sys_subject S left join sys_period P on P.id=S.period where S.id=$user_subject")->fetchColumn(0));
	$pagesize = 15;
	
	switch($qname){
		
		case "index":		## ѧ�ƹ�����̨��ҳ.htm
			$T->ReadDB("SELECT * from `subjecter` where parentid=0");
			break;
			
		case "article_type" :	## ���·������
			$T->SetBlock("list", 
				@"select T.*,(select count(1) from subjecter_articles t2 where t2.typeid=T.id) as count,
				S.name as subject_name, P.name as period_name
				from `subjecter_article_type` T 
				left join sys_subject S on S.id=T.subject 
				left join sys_period P on P.id=S.period
				where subject=$user_subject order by odx");
			break;
			
		case "slides" :	## �õ�Ƭ
			$T->SetBlock("list", "select * from `subjecter` where parentid=".$subjecterId." and template='".$tplName."' order by odx");
			break;
			
		case "article_add":	## ��������
			// Ԥ������ѧ�ι�����ѧ������
			$T->SetTpl('subject_and_grade_cache', get_subject_and_grade_cachefile());
			
			// �������ʼ��
			initPeriodSelect($T);
			initArticleSelect($user_subject, '�����·��ࡪ', $T);
			break;
			
		case "articles" :	## ���¹���
			// Ԥ������ѧ�ι�����ѧ������
			$T->SetTpl('subject_and_grade_cache', get_subject_and_grade_cachefile());
			
			// �������ʼ��
			initPeriodSelect($T);
			initArticleSelect($user_subject, '�����ࡪ', $T);
			$T->Set("srctitle", isset($_GET["title"]) ? $_GET["title"] : "");
			
			$p = isset($_GET["p"]) ? $_GET["p"] : "1";	// Ĭ�ϵ�ǰ��һҳ
			
			$searchArray = array(
				'id'=>isset($_GET["id"]) ? $_GET["id"] : "",
				'title'=>isset($_GET["title"]) ? $_GET["title"] : "",
				'period'=>isset($_GET["per"]) ? $_GET["per"] : "",
				'subject'=>isset($_GET["sjt"]) ? $_GET["sjt"] : "",
				'typeid'=>isset($_GET["tid"]) ? $_GET["tid"] : "",
				'recommended'=>isset($_GET["rec"]) ? $_GET["rec"] : ""
			);
			$srcSql = getSearchSql('t1', $searchArray);	// ���ز�ѯ������sql���
			
			$state = isset($_GET["state"]) ? $_GET["state"] : "";
			if( $state != "" ) {
				if($state == "2") {
					$srcSql .= " and t1.state=".$state;
				} else {
					$srcSql .= " and t1.state!=2";
				}
			}
			$srcSql .= " and t1.subject=$user_subject";
			
			$rc = getAllArticlesCount($T, $srcSql);	// ��ѯ��¼������ɸѡ���úͽ��õ�ѧ��
			if($rc > $pagesize) {
				$page = getPageHtml_bt($rc, $pagesize, $p, 
								"&t=articles"
								."&title=".$searchArray['title']
								."&per=".$searchArray['period']
								."&sjt=".$searchArray['subject']
								."&tid=".$searchArray['typeid']
								."&state=".$state
								."&rec=".$searchArray['recommended']);
				$T->Set("page",$page);
			}
			
			getAllArticles($T, $srcSql, $p, $pagesize);
			break;
			
		case "templates":
			$templates = get_all_dir('../html/', 'public');
			$T->Set("tmp_imgs", showTemplates($templates));
			$T->Set("tmp_radios", showTmpRadios($templates, $tplName));
			break;
			
		case "periods":
			$condition = isset($_GET["c"]) ? $_GET["c"] : "g";
			
			// ��ɾ��ѧ�ε���������
			// $sql = "select *,";
			// $sql .= " (select count(1) from subjecter_books where period=sp.id) as books_count,";
			// $sql .= " (select count(1) from act_member where period=sp.id) as members_count,";
			// $sql .= " (select count(1) from sys_grade where period=sp.id) as grades_count,";
			// $sql .= " (select count(1) from sys_subject where period=sp.id) as subjects_count";
			// $sql .= " from `sys_period` sp order by odx";
			
			$sql = getQueryPeriodSql(0);
			
			switch($condition) {
				case "g" :
					$T->Set("show_href", '<a href="?t=periods&c=s">��ѧ����ʾ</a>');
					$T->Set("show_c", 'ӵ���꼶');
					$T->SetBlock2("cate", $sql,
						array(array("block"=>"rp", "pid"=>"id", "sql"=>"select `name` from sys_grade where period=?")));
					break;
				case "s" :
					$T->Set("show_href", '<a href="?t=periods">���꼶��ʾ</a>');
					$T->Set("show_c", 'ӵ��ѧ��');
					$T->SetBlock2("cate", $sql,
						array(array("block"=>"rp", "pid"=>"id", "sql"=>"select `name` from sys_subject where school=0 and period=?")));
					break;
			}
			break;
			
		case "grades":
			$period = isset($_GET["per"]) ? $_GET["per"] : "";	// ��ȡѧ��
			block_bind_by_period("list_period", $T);
			initPeriodOptions("sel_period", '��ѧ��ѡ��', $T);
			
			// ��ɾ���꼶����������
			// $sql = "select *, ";
			// $sql .= " (select count(1) from subjecter_books where grade=sg.id) as books_count, ";
			// $sql .= " (select count(1) from act_member where grade=sg.id) as members_count, ";
			// $sql .= " (select count(1) from sub_resources where grade=sg.id) as sub_res_count ";
			// $sql .= " from `sys_grade` sg order by period, odx";
			
			$sql = "select sg.name,sg.odx,sg.id,sg.period,sp.name as period_name from `sys_grade` sg";
			$sql .= " left join sys_period sp on sp.id=sg.period";
			$sql .= " where sp.display=1";
			if( $period != "" )
				$sql .= " and sg.period=".$period;
			$sql .= " order by sg.period, sg.odx";
			
			$T->SetBlock("list", $sql);

			break;
			
		case "subjects":
			$period = isset($_GET["per"]) ? $_GET["per"] : "";	// ��ȡѧ��
			block_bind_by_period("list_period", $T);
			initPeriodOptions("sel_period", '��ѧ��ѡ��', $T);
			
			// ��ɾ��ѧ�Ƶ���������
			// $sql = "select *, ";
			// $sql .= " (select count(1) from subjecter_books where subject=ss.id) as books_count, ";
			// $sql .= " (select count(1) from act_member where subject=ss.id) as members_count, ";
			// $sql .= " (select count(1) from subjecter_articles where subject=ss.id) as sbjter_count, ";
			// $sql .= " (select count(1) from sub_articles where subject=ss.id) as sub_art_count, ";
			// $sql .= " (select count(1) from sub_resources where subject=ss.id) as sub_res_count ";
			// $sql .= " from `sys_subject` ss order by period, odx";
			
			$sql = "select ss.id, ss.period, ss.name, ss.odx, sp.name as period_name from `sys_subject` ss";
			$sql .= " left join sys_period sp on sp.id=ss.period";
			$sql .= " where ss.school=0 and sp.display=1";
			if( $period != "" )
				$sql .= " and ss.period=".$period;
			$sql .= " order by ss.period, ss.odx";
			
			$T->SetBlock("list", $sql);
			
			break;
		
		case "versions":
			$T->SetBlock("list", "SELECT * from `sys_textbook_edition` order by odx");
			break;
			
		case "restypes":
			$T->SetBlock("list", "SELECT * from `res_type` order by odx");
			break;
		
		case "volumes":
			$T->SetBlock("list", "SELECT * from `sys_textbook_volume` order by odx");
			break;
			
		case "books":
			$T->Set("srctitle", isset($_GET["title"]) ? $_GET["title"] : "");
			
			// Ԥ������ѧ�ι���������
			$T->SetTpl('subject_and_grade_cache', get_subject_and_grade_cachefile());
			initPeriodSelect($T);
			initEditionSelect($T);
			initVolumeSelect($T);
			
			$yearOpts = initYearOptions($T);
			$T->Set("list_year", $yearOpts);
			$T->Set("form_year", $yearOpts);
			
			$p = isset($_GET["p"]) ? $_GET["p"] : "1";	// Ĭ�ϵ�ǰ��һҳ
			
			$searchArray = array(
				'title'=>isset($_GET["title"]) ? $_GET["title"] : "",
				'period'=>isset($_GET["per"]) ? $_GET["per"] : "",
				'subject'=>isset($_GET["sub"]) ? $_GET["sub"] : "",
				'grade'=>isset($_GET["gra"]) ? $_GET["gra"] : "",
				'edition'=>isset($_GET["edi"]) ? $_GET["edi"] : "",
				'volume'=>isset($_GET["vol"]) ? $_GET["vol"] : "",
				'year'=>isset($_GET["yea"]) ? $_GET["yea"] : "",
				'required'=>isset($_GET["req"]) ? $_GET["req"] : ""
			);
			
			# where�Ӿ�
			$srcSql = getSearchSql('B', $searchArray);
			$orderBy = "B.id desc";
			
			if($searchArray['title']="" && $searchArray['period'] != "" && $searchArray['subject'] != "" && $searchArray['grade'] != "" && $searchArray['edition'] != "" && $searchArray['volume'] != "" && $searchArray['year'] != "" && $searchArray['required'] != "") {
				$orderBy = "B.odx";
			}
			
			$rc = $T->db->query(
			@"select count(1) from `sys_textbook` B 
			left join sys_period P on P.id=B.period 
			where B.id>=0 and P.display=1".$srcSql)->fetchColumn(0);	// ��ѯ��¼����
			
			if($rc > $pagesize) {
				$page = getPageHtml_bt($rc, $pagesize, $p, 
								"&t=books"
								."&title=".$searchArray['title']
								."&per=".$searchArray['period']
								."&sub=".$searchArray['subject']
								."&gra=".$searchArray['grade']
								."&edi=".$searchArray['edition']
								."&vol=".$searchArray['volume']
								."&yea=".$searchArray['year']
								."&req=".$searchArray['required']);
				$T->Set("page",$page);
			}
			
			$sql = "SELECT B.id, B.title, B.odx, B.year, B.required, B.period, B.grade, B.subject, B.edition, B.volume, B.timestamp, B.uid,";
			$sql .= "P.name as period_name,";
			$sql .= "S.name as subject_name,";
			$sql .= "G.name as grade_name,";
			$sql .= "E.name as edition_name,";
			$sql .= "V.name as volume_name,";
			$sql .= "(select count(1) from sys_books_chapters where book=B.id and parentid=0) as chapters_count,";
			$sql .= "(select count(1) from sys_books_chapters where book=B.id and parentid!=0) as sub_chapters_count";
			$sql .= " from `sys_textbook` B";
			$sql .= " left join sys_period P on P.id=B.period";
			$sql .= " left join sys_subject S on S.id=B.subject";
			$sql .= " left join sys_grade G on G.id=B.grade";
			$sql .= " left join sys_textbook_edition E on E.id=B.edition";
			$sql .= " left join sys_textbook_volume V on V.id=B.volume";
			$sql .= " where B.id>0 and P.display=1 ".$srcSql;
			$sql .= " order by ".$orderBy." limit ".(($p - 1) * $pagesize).", $pagesize";
			
			$T->SetBlock("list", $sql);
			break;
			
		case "chapters":
			// Ԥ������ѧ�ι�����ѧ������
			$T->SetTpl('subject_and_grade_cache', get_subject_and_grade_cachefile());
			initPeriodSelect($T);
			initEditionSelect($T);
			initVolumeSelect($T);
			$yearOpts = initYearOptions($T);
			$T->Set("list_year", $yearOpts);
			
			$book = isset($_GET["book"]) ? $_GET["book"] : "";
			if( $book != "" ) {
				// ���ݷ��෵�ض�Ӧ�����µ����пα�
				$T->Set("all_books", getBooksOptions($user_period, $user_subject, $T));
			}
			
			# ��������
			$p = isset($_GET["p"]) ? $_GET["p"] : "1";	// Ĭ�ϵ�ǰ��һҳ
			
			# where�Ӿ�
			$srcSql = "";
			$searchArray = array(
					'period'=>isset($_GET["per"]) ? $_GET["per"] : "",
					'subject'=>isset($_GET["sub"]) ? $_GET["sub"] : "",
					'grade'=>isset($_GET["gra"]) ? $_GET["gra"] : "",
					'edition'=>isset($_GET["edi"]) ? $_GET["edi"] : "",
					'volume'=>isset($_GET["vol"]) ? $_GET["vol"] : "",
					'year'=>isset($_GET["yea"]) ? $_GET["yea"] : "",
					'required'=>isset($_GET["req"]) ? $_GET["req"] : ""
				);
			
			if( $searchArray['period'] != "" && $searchArray['subject'] != "" && $searchArray['grade'] != "" ) {
				// ���ݷ��෵�ض�Ӧ�����µ����пα�
				$T->Set("all_books", getBooksOptions($user_period, $user_subject, $T));
			}
				
			if( $book != "" ) {
				// ָ���α�����
				$srcSql = " and C.book=".$book;
			} else {
				$srcSql = getSearchSql('B', $searchArray);	// ���ز�ѯ������sql���
			}
			
			$rc = getChaptersCount($srcSql, $T);	// ��ѯ��¼����
			
			if($rc > $pagesize) {
				$page = getPageHtml_bt($rc, $pagesize, $p, 
							"&t=chapters"
							."&book=".$book
							."&per=".$searchArray['period']
							."&sub=".$searchArray['subject']
							."&gra=".$searchArray['grade']
							."&edi=".$searchArray['edition']
							."&vol=".$searchArray['volume']
							."&yea=".$searchArray['year']
							."&req=".$searchArray['required']);
				$T->Set("page",$page);
			}
			
			$orderBy = $book != "" ? "C.odx" : "C.id desc";
			
			$sql = "SELECT C.id, C.title, C.book, C.parentid, C.odx,";
			$sql .= "B.title as book_title, B.period, B.subject, B.grade, B.edition, B.volume, B.year, B.required,";
			$sql .= "(select count(1) from sys_books_chapters where parentid=C.id) as parts_count,";
			$sql .= "P.name as period_name,";
			$sql .= "S.name as subject_name,";
			$sql .= "G.name as grade_name,";
			$sql .= "E.name as edition_name,";
			$sql .= "V.name as volume_name";
			$sql .= " from sys_books_chapters C";
			$sql .= " left join sys_textbook B on B.id=C.book";
			$sql .= " left join sys_period P on P.id=B.period";
			$sql .= " left join sys_subject S on S.id=B.subject";
			$sql .= " left join sys_grade G on G.id=B.grade";
			$sql .= " left join sys_textbook_edition E on E.id=B.edition";
			$sql .= " left join sys_textbook_volume V on V.id=B.volume";
			$sql .= " where C.parentid=0 and P.display=1 ".$srcSql." order by ".$orderBy." limit ".(($p - 1) * $pagesize).", $pagesize";
			
			$T->SetBlock("list", $sql);
			break;
		
		case "parts":
			// Ԥ������ѧ�ι�����ѧ������
			$T->SetTpl('subject_and_grade_cache', get_subject_and_grade_cachefile());
			initPeriodSelect($T);
			initEditionSelect($T);
			initVolumeSelect($T);
			$yearOpts = initYearOptions($T);
			$T->Set("list_year", $yearOpts);
			
			$searchArray = array(
					'id'=>isset($_GET["book"]) ? $_GET["book"] : "",
					'period'=>isset($_GET["per"]) ? $_GET["per"] : "",
					'subject'=>isset($_GET["sub"]) ? $_GET["sub"] : "",
					'grade'=>isset($_GET["gra"]) ? $_GET["gra"] : "",
					'edition'=>isset($_GET["edi"]) ? $_GET["edi"] : "",
					'volume'=>isset($_GET["vol"]) ? $_GET["vol"] : "",
					'year'=>isset($_GET["yea"]) ? $_GET["yea"] : "",
					'required'=>isset($_GET["req"]) ? $_GET["req"] : ""
				);
			$book = isset($_GET["book"]) ? $_GET["book"] : "";
			if( $book != "" || ($searchArray['period'] != "" && $searchArray['subject'] != "" && $searchArray['grade'] != "")) {
				// ���ݷ��෵�ض�Ӧ�����µ����пα�
				$T->Set("all_books", getBooksOptions($user_period, $user_subject, $T));
			}
			
			if($book != "") {
				// ���ݿα����������½�
				$sql = "select id, title from sys_books_chapters where parentid=0 and book=".$book." order by odx";
				$T->Set("all_chapters", getChapters($sql, $T));
			}
			
			# ��������
			$p = isset($_GET["p"]) ? $_GET["p"] : "1";	// Ĭ�ϵ�ǰ��һҳ
			
			# where�Ӿ�
			$srcSql = "";
			$chapter = isset($_GET["cha"]) ? $_GET["cha"] : "";
			
			if( $chapter != "" ) {
				$srcSql = " and C.parentid=".$chapter;
			} else {
				$srcSql = getSearchSql('B', $searchArray);	// ���ز�ѯ������sql���
			}
			
			$rc = getPartsCount($srcSql, $T);	// ��ѯ��¼����
			if($rc > $pagesize) {
				$page = getPageHtml_bt($rc, $pagesize, $p, 
								"&t=parts"
								."&cha=".$chapter
								."&book=".$searchArray['id']
								."&per=".$searchArray['period']
								."&sub=".$searchArray['subject']
								."&gra=".$searchArray['grade']
								."&edi=".$searchArray['edition']
								."&vol=".$searchArray['volume']
								."&yea=".$searchArray['year']
								."&req=".$searchArray['required']);
				$T->Set("page",$page);
			}
			
			$orderBy = $book != "" ? "C.odx" : "C.id desc";
			
			$sql = "SELECT C.id, C.title, C.book, C.parentid, C.odx,";
			$sql .= " B.title as book_title, B.period, B.subject, B.grade, B.edition, B.volume, B.year, B.required,";
			$sql .= "C2.title as chapter_title,";
			$sql .= "P.name as period_name,";
			$sql .= "S.name as subject_name,";
			$sql .= "G.name as grade_name,";
			$sql .= "E.name as edition_name,";
			$sql .= "V.name as volume_name";
			$sql .= " from sys_books_chapters C";
			$sql .= " left join sys_textbook B on B.id=C.book";
			$sql .= " left join sys_books_chapters C2 on C2.id=C.parentid";
			$sql .= " left join sys_period P on P.id=B.period";
			$sql .= " left join sys_subject S on S.id=B.subject";
			$sql .= " left join sys_grade G on G.id=B.grade";
			$sql .= " left join sys_textbook_edition E on E.id=B.edition";
			$sql .= " left join sys_textbook_volume V on V.id=B.volume";
			$sql .= " where C.parentid!=0 and P.display=1 ".$srcSql." order by ".$orderBy." limit ".(($p - 1) * $pagesize).", $pagesize";
			
			$T->SetBlock("list", $sql);
			break;
			
		case "resources":
			// Ԥ������ѧ�ι�����ѧ�����ݣ����棩
			$T->SetTpl('subject_and_grade_cache', get_subject_and_grade_cachefile());

			initPeriodSelect($T);
			initEditionSelect($T);
			initVolumeSelect($T);
			initResTypeSelect("list_restype", $T);
			$yearOpts = initYearOptions($T);
			$T->Set("list_year", $yearOpts);
			$T->Set("srctitle", isset($_GET["title"]) ? $_GET["title"] : "");
			
			$p = isset($_GET["p"]) ? $_GET["p"] : "1";	// Ĭ�ϵ�ǰ��һҳ
			
			$searchArray = array(
				'title'=>isset($_GET["title"]) ? $_GET["title"] : "",
				'restype'=>isset($_GET["res"]) ? $_GET["res"] : "",
				'period'=>$user_period,
				'subject'=>$user_subject,
				'grade'=>isset($_GET["gra"]) ? $_GET["gra"] : "",
				'book'=>isset($_GET["boo"]) ? $_GET["boo"] : "",
				'chapter'=>isset($_GET["cha"]) ? $_GET["cha"] : "",
				'part'=>isset($_GET["par"]) ? $_GET["par"] : "",
				'edition'=>isset($_GET["edi"]) ? $_GET["edi"] : "",
				'volume'=>isset($_GET["vol"]) ? $_GET["vol"] : "",
				'year'=>isset($_GET["yea"]) ? $_GET["yea"] : "",
				'required'=>isset($_GET["req"]) ? $_GET["req"] : ""
			);
			
			if( $searchArray['book'] != "" || ($searchArray['period'] != "" && $searchArray['subject'] != "" && $searchArray['grade'] != "")) {
				// ���ݷ��෵�ض�Ӧ�����µ����пα�
				$T->Set("all_books", getBooksOptions($user_period, $user_subject, $T));
			}
			
			if($searchArray['book'] != "") {
				// ���ݿα����������½�
				$sql = "select id, title from sys_books_chapters where parentid=0 and book=".$searchArray['book']." order by odx";
				$T->Set("all_chapters", getChapters($sql, $T));
			}
			
			if($searchArray['chapter'] != "") {
				$sql = "select id, title from sys_books_chapters where parentid=".$searchArray['chapter']." order by odx";
				$T->Set("all_parts", getChapters($sql, $T));
			}
			
			$srcSql = getSearchSql('R', $searchArray);	// ���ز�ѯ������sql���
			$srcSql .= " and R.subject=$user_subject";
			$orderBy = "R.id desc";
			
			$rc = $T->db->query("select count(1) from `subjecter_resources` R where R.id>=0 ".$srcSql)->fetchColumn(0);	// ��ѯ��¼����
			if($rc > $pagesize) {
				$page = getPageHtml_bt($rc, $pagesize, $p, 
								"&t=resources"
								."&title=".$searchArray['title']
								."&res=".$searchArray['restype']
								."&per=".$searchArray['period']
								."&sub=".$searchArray['subject']
								."&gra=".$searchArray['grade']
								."&boo=".$searchArray['book']
								."&cha=".$searchArray['chapter']
								."&par=".$searchArray['part']
								."&edi=".$searchArray['edition']
								."&vol=".$searchArray['volume']
								."&yea=".$searchArray['year']
								."&req=".$searchArray['required']);
				$T->Set("page",$page);
			}
			
			$sql = @"select R.*, M.truename, SCH.name as school_name, T.name as restype_name, 
					P.name as period_name, S.name as sub_name, G.name as grade_name,
					BOOK.title as book_name, CHA.title as chapter_name, PAR.title as part_name,
					E.name as edition_name, V.name as volume_name
					
					from subjecter_resources R 
					
					left join act_member M on M.id=R.uid 
					left join school SCH on SCH.id=M.school 
					left join res_type T on T.id=R.restype 
					
					left join sys_period P on P.id=R.period 
					left join sys_subject S on S.id=R.subject 
					left join sys_grade G on G.id=R.grade 
					
					left join sys_textbook BOOK on BOOK.id=R.book 
					left join sys_books_chapters CHA on CHA.id=R.chapter 
					left join sys_books_chapters PAR on PAR.id=R.part
					
					left join sys_textbook_edition E on E.id=R.edition  
					left join sys_textbook_volume V on V.id=R.volume  
					where R.id>0 ".$srcSql." order by ".$orderBy;
					
			$T->SetBlock("list_res", $sql);
			break;
			
		case "resource_add":
			$T->SetTpl('subject_and_grade_cache', get_subject_and_grade_cachefile());
			initPeriodSelect($T);
			initEditionSelect($T);
			initVolumeSelect($T);
			initResTypeSelect("list_restype", $T);
			$yearOpts = initYearOptions($T);
			$T->Set("list_year", $yearOpts);
			$T->Set("PAN_URL",PAN_URL);
			
			$id = isset($_GET['id']) ? $_GET['id'] : "";
			if($id != "") {
				init_edit_page($id, $T);	// �༭ҳ������ݳ�ʼ��
				$T->ReadDB("SELECT * from subjecter_resources where id=".$id);
			}
			break;
	}
	
	$T->Set("subjecterId", $subjecterId);
	$T->Set("user_period",$user_period);
	$T->Set("user_subject",$user_subject);
	$T->Set('tplno', $tplName);
	$T->Set("gtitle",LR_NAME);
	$T->clearNaN();
	$T->clearNoN();   
	$T->display();
	$T->close();
	unset($T);