<?php 
/*调用 pan 数据 新接口
*/
header("Content-type: text/html; charset=utf-8;"); 
require '../../../cfg/config.inc';
require '../../../ppf/fun.php';

if (!session_id()) session_start(); 
chkLoginNoJump("uid"); 
$uid=$_SESSION['uid'];  
$id = isset($_POST['id'])?intval($_POST['id']) : 0;
echo file_get_contents(PAN_URL.'api/yun?t=get_dir2&id='.$id.'&uid='.$uid);