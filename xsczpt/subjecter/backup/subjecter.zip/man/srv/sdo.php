<?php 
header("Content-type: text/html; charset=utf-8;"); 
require '../../../ppf/fun.php';
require '../../../ppf/pdo_mysql.php';

if (!session_id()) session_start();  
chkLoginNoJump("uid");
$uid = $_SESSION['uid'];

$pd=new pdo_mysql();
switch($_POST["tpl"]){
	case "del_article":	## 删除文章
		$pd->exec("delete from `subjecter_articles` where id=".$_POST["id"]);
		echo "ok";  
		break;        
	case "article_audit": ## 审核文章
		$pd->exec("update `subjecter_articles` set state=2 where id=".$_POST["id"]);
		echo "ok";  
		break;           
	case "article_recommended": ## 推荐文章
		$pd->exec("update `subjecter_articles` set recommended=1 where id=".$_POST["id"]);
		echo "ok";  
		break;
	case "del_article_type" :	## 删除文章分类
		$pd->exec("delete from `subjecter_article_type` where id=".$_POST["id"]);
		echo "ok";
		break;
	case "del_grade" :	## 删除年级
		// $pd->exec("delete from `sys_grade` where id=".$_POST["id"]);
		// echo "ok";
		break;
	case "del_subject" :	## 删除学科
		// $pd->exec("delete from `sys_subject` where id=".$_POST["id"]);
		// echo "ok";
		break;
	case "del_slide":	### 删除幻灯片
		$pic = $pd->query("select `pic` from subjecter where id=".$_POST["id"])->fetchColumn(0);
		$pd->exec("delete from `subjecter` where id=".$_POST["id"]);
		unlink("../".$pic);		// 删除图片（删除初始目录和删除每次上传目录）
		unlink(DIR_ROOT.$pic);
		echo "ok";
		break;
	case "chs_tmplate":
		$pd->exec("update `subjecter` set template='".$_POST["id"]."' where parentid=0");
		echo "ok";
		break;
	case "del_versions":	// 删除教材版本
		// $pd->exec("delete from sys_textbook_edition where id=".$_POST["id"]);
		// echo "ok";
		break;
	case "del_restypes":	// 删除资源类型
		// $pd->exec("delete from res_type where id=".$_POST['id']);
		// echo "ok";
		break;
	case "add_books":	// 批量添加课文
		$timer = new Timer();
		$timer->start();
		
		$data = base64_decode($_POST["data"]);
		$arr = explode("\n", $data);
		$period = $_POST["period"];
		$subject = $_POST["subject"];
		$grade = $_POST["grade"];
		$edition = $_POST["edition"];
		$volume = $_POST["volume"];
		$year = $_POST["year"];
		$required = $_POST["required"];
		
		$result = "";
		$error = 0;
		$odx = 1;
		for($i=0; $i < count($arr); $i++){
			//$title = str_replace(array(" ","　","\t","\n","\r"), '', $arr[$i]);
			$title = trimSpace($arr[$i]);
			
			if(strlen($title) != 0) {
				$resCount = $pd->query("select count(1) from sys_textbook where title='".$title."' and period=".$period." and subject=".$subject." and grade=".$grade." and edition=".$edition." and volume=".$volume." and year=".$year." and required=".$required)->fetchColumn(0);
				
				if($resCount > 0) {
					$error++;
					echo $result = "行".($i+1)."："."数据重复。（失败".$error."）".PHP_EOL;
				} else {
					$pd->exec("insert into sys_textbook (`id`, `uid`, `period`, `grade`, `subject`, `edition`, `volume`, `year`, `required`, `odx`, `timestamp`, `title`) select max(id)+1, '$uid', $period, $grade, $subject, $edition, $volume, $year, $required, ".$odx.", UNIX_TIMESTAMP(), '$title' from sys_textbook");
					$odx++;
					echo $result = "行".($i+1)."："."导入成功。".PHP_EOL;
				}
			} else {
				$error++;
				echo $result = "行".($i+1)."："."空行，无数据。（失败".$error."）".PHP_EOL;
			}
		}
		
		$timer->stop();
		echo "\n----------------------------------------------\n导入完毕，用时 ".$timer->spent()." 秒。（成功 ".($odx - 1)." 条，失败 $error 条。）";
		break;
		
	case "add_chapters":	// 批量添加章节
		$timer = new Timer();
		$timer->start();
		
		$data = base64_decode($_POST["data"]);
		$arr = explode("\n", $data);
		$book = $_POST["book"];
		
		$result = "";
		$error = 0;
		$odx = 1;
		for($i=0; $i < count($arr); $i++){
			//$title = str_replace(array(" ","　","\t","\n","\r"), '', $arr[$i]);
			$title = trimSpace($arr[$i]);
			
			if(strlen($title) != 0) {
				$resCount = $pd->query("select count(1) from sys_books_chapters where parentid=0 and title='".$title."' and book=".$book)->fetchColumn(0);
				
				if($resCount > 0) {
					$error++;
					echo $result = "行".($i+1)."："."数据重复。（失败".$error."）".PHP_EOL;
				} else {
					$pd->exec("insert into sys_books_chapters (`id`, `uid`, `title`, `book`, `odx`, `parentid`, `timestamp`) select max(id)+1, '$uid', '$title', $book, $odx, 0, UNIX_TIMESTAMP() from sys_books_chapters");
					$odx++;
					echo $result = "行".($i+1)."："."导入成功。".PHP_EOL;
				}
			} else {
				$error++;
				echo $result = "行".($i+1)."："."空行，无数据。（失败".$error."）".PHP_EOL;
			}
		}
		
		$timer->stop();
		echo "\n----------------------------------------------\n导入完毕，用时 ".$timer->spent()." 秒。（成功 ".($odx - 1)." 条，失败 $error 条。）";
		break;
		
	case "add_parts":	// 添加子节
		$timer = new Timer();
		$timer->start();
		
		$data = base64_decode($_POST["data"]);
		$arr = explode("\n", $data);
		$book = $_POST["book"];
		$parentid = $_POST["parentid"];
		
		$result = "";
		$error = 0;
		$odx = 1;
		for($i=0; $i < count($arr); $i++){
			//$title = str_replace(array(" ","　","\t","\n","\r"), '', $arr[$i]);
			$title = trimSpace($arr[$i]);

			if(strlen($title) != 0) {
				$resCount = $pd->query("select count(1) from sys_books_chapters where parentid=".$parentid." and title='".$title."'")->fetchColumn(0);
				
				if($resCount > 0) {
					$error++;
					echo $result = "行".($i+1)."："."数据重复。（失败".$error."）".PHP_EOL;
				} else {
					$pd->exec("insert into sys_books_chapters (`id`, `uid`, `title`, `book`, `odx`, `parentid`, `timestamp`) select max(id)+1, '$uid', '$title', $book, $odx, $parentid, UNIX_TIMESTAMP() from sys_books_chapters");
					$odx++;
					//file_put_contents($i.".htm", nl2br("　　"));
					echo $result = "行".($i+1)."："."导入成功。".PHP_EOL;
				}
			} else {
				$error++;
				echo $result = "行".($i+1)."："."空行，无数据。（失败".$error."）".PHP_EOL;
			}
		}
		
		$timer->stop();
		echo "\n----------------------------------------------\n导入完毕，用时 ".$timer->spent()." 秒。（成功 ".($odx - 1)." 条，失败 $error 条。）";
		break;
	case "save_parts_sort":	# 保存子节排序
		$data = $_POST["data"];
		$arr = explode(";", $data);
		
		for($i=0; $i < count($arr); $i++){
			$tmp = $arr[$i];
			if(strlen($tmp) > 0) {
				$arr_val = explode(":", $arr[$i]);
				$id = $arr_val[0];
				$odx = $arr_val[1];
				$pd->exec("update sys_books_chapters set odx=$odx where `id`=$id and parentid!=0");
			}
		}
		echo "ok";
		break;
	case "save_chapters_sort":	# 保存 章 排序
		$data = $_POST["data"];
		$arr = explode(";", $data);
		
		for($i=0; $i < count($arr); $i++){
			$tmp = $arr[$i];
			if(strlen($tmp) > 0) {
				$arr_val = explode(":", $arr[$i]);
				$id = $arr_val[0];
				$odx = $arr_val[1];
				$pd->exec("update sys_books_chapters set odx=$odx where `id`=$id and parentid=0");
			}
		}
		echo "ok";
		break;
		
	case "delete_cache_htm":	# 删除head.htm缓存文件
		// 1.删除后台使用的select级联菜单subject_and_grade_cache.htm缓存
		if(file_exists('../html/subject_and_grade_cache.htm')) {
			unlink('../html/subject_and_grade_cache.htm');
		}
		
		// 2.删除前台页面每种模板使用的head.htm缓存
		$stmt = $pd->query("select distinct(`template`) from subjecter");
	
		foreach($stmt as $row) {
			foreach($row as $tpl_name) {
				if(file_exists('../../html/'.$tpl_name.'/head.htm')) {
					unlink('../../html/'.$tpl_name.'/head.htm');
				}
			}
		}
		echo "ok";
		break;
		
	case "resource_recommended": # 推荐资源
		$pd->exec("update `subjecter_resources` set recommended=1 where id=".$_POST["id"]);
		echo "ok";  
		break;
		
	case "cancel_recommended": # 推荐资源
		$pd->exec("update `subjecter_resources` set recommended=0 where id=".$_POST["id"]);
		echo "ok";  
		break;
	
	case "resource_audit": # 审核资源
		$pd->exec("update `subjecter_resources` set state=2 where id=".$_POST["id"]);
		echo "ok";  
		break;
		
	case "del_resource" :	# 删除发布资源
		$pd->exec("delete from `subjecter_resources` where id=".$_POST["id"]);
		unlink("../../../upds/subjecter/img/reslogo/".$_POST["id"].".gif");
		unlink("../../../upds/subjecter/img/reslogo/".$_POST["id"].".jpg");
		unlink("../../../upds/subjecter/img/reslogo/".$_POST["id"].".png");
		echo "ok";
		break;
		
	case "edit_edition" :
		$id = $_POST["id"];
		$name = $_POST["name"];
		$odx = $_POST["odx"];
		$do_res = "";
		
		$oldName = $pd->query("select `name` from sys_textbook_edition where `id`=$id")->fetchColumn(0);
		if($name == $oldName) {
			// 编辑其他数据 odx
			$pd->exec("update sys_textbook_edition set odx=$odx where id=$id");
			$do_res = 'ok';
		} else {
			// 判断相同数据是否存在，不存在则根据id整个更新
			$samedata = $pd->query("select count(1) from sys_textbook_edition where `name`='$name'")->fetchColumn(0);
			if( $samedata > 0 ) {
				$do_res = "failed";
			} else {
				$pd->exec("update sys_textbook_edition set `name`='$name', odx=$odx where id=$id");
				$do_res = 'ok';
			}
		}
		
		echo $do_res;
		break;
		
	case "add_edition" :
		$name = $_POST["name"];
		$odx = $_POST["odx"];
		$do_res = "";
		$samedata = $pd->query("select count(1) from sys_textbook_edition where `name`='$name'")->fetchColumn(0);
		if( $samedata > 0 ) {
			$do_res = "failed";
		} else {
			$result = $pd->prepare(@"insert into sys_textbook_edition (`id`, `name`, `odx`, timestamp) select max(id)+1, :name, :odx, UNIX_TIMESTAMP() from sys_textbook_edition");
			$result->bindParam(':name', $name);
			$result->bindParam(':odx', $odx);
			$result->execute();
			$do_res = "ok";
		}
		echo $do_res;
		break;
		
	case "edit_resource":
		$dotype = $_POST["dotype"];
		$id = $_POST["id"];
		$title = $_POST["title"];
		$des = $_POST["des"];
		$content = $_POST["content"];
		$restype = $_POST["restype"];
		$original = $_POST["original"];
		
		$ressuffix = $_POST["ressuffix"];
		$resname = $_POST["resname"];
		$resmd5 = $_POST["resmd5"];
		
		$period = $_POST["period"];
		$subject = $_POST["subject"];
		$grade = $_POST["grade"];
		
		$edition = $_POST["edition"];
		$volume = $_POST["volume"] == "" ? "NULL" : $_POST["volume"];
		$year = $_POST["year"];
		$required = $_POST["required"];
		
		$book = $_POST["book"] == "" ? "NULL" : $_POST["book"];
		$chapter = $_POST["chapter"] == "" ? "NULL" : $_POST["chapter"];
		$part = $_POST["part"] == "" ? "NULL" : $_POST["part"];
		$postdate = $_POST["postdate"];
		
		$sql = "";
		
		switch($dotype) {
			case "a":
				// 新增
				$sql = @"INSERT INTO `subjecter_resources` 
						(`id`, `uid`, `title`, `des`, `content`, `restype`, `original`, `ressuffix`, `resname`, `resmd5`, `period`, `subject`, `grade`, `book`, `chapter`, `part`, `edition`, `volume`, `required`, `year`, `postdate`, `timestamp`, `state`, `download`, `recommended`) 
						select max(id)+1, '$uid', '$title', '$des', '$content', '$restype', '$original', 
						'$ressuffix', '$resname', '$resmd5', '$period', '$subject', '$grade', $book, $chapter, $part, 
						'$edition', $volume, '$required', '$year', '$postdate', UNIX_TIMESTAMP(), '2', '0', '0' 
						from `subjecter_resources`";
				break;
				
			case "m":
				// 修改
				$sql = @"UPDATE `subjecter_resources` SET 
						`uid`='$uid', `title`='$title', `des`='$des', `content`='$content', `restype`='$restype', 
						`original`='$original', `ressuffix`='$ressuffix', `resname`='$resname', `resmd5`='$resmd5',
						`period`='$period', `subject`='$subject', `grade`='$grade', 
						`book`=$book, `chapter`=$chapter, `part`=$part,
						`edition`='$edition', `volume`=$volume, `required`='$required', `year`='$year',
						`timestamp`=UNIX_TIMESTAMP() 
						WHERE `id`=$id";
				break;
		}
		
		$pd->exec($sql);
		echo "ok";
		break;
}

function trimSpace($str) {
	$str = mb_ereg_replace('^(　| )+', '', $str); 
	$str = mb_ereg_replace('(　| )+$', '', $str); 
	return mb_ereg_replace('　　', "n　　", $str);
}

class Timer {
	private $startTime;
	private $stopTime;

	function __construct(){
		$this->startTime=0;
		$this->stopTime=0;
	}

	function start(){
		$this->startTime=microtime(true);
	}

	function stop(){
		$this->stopTime=microtime(true);
	}

	function spent(){
		return round(($this->stopTime-$this->startTime), 4);	// 得到小数点后4位
	}
}

$pd->close();
unset($pd);
unset($rs);