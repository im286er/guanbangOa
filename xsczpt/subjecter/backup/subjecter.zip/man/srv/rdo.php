﻿<?php 
	header("Content-type: text/html; charset=utf-8;");
	require '../../../ppf/fun.php';
	require '../../../ppf/pdo_mysql.php';
	require 'pdo_template.php';

	if (!session_id()) session_start(); 
	chkLoginNoJump("uid");  
	$uid = $_SESSION["uid"];
	 
	$pd=new pdo_mysql();

	switch($_POST["tpl"]){
		case "get_article_type": ## 文章分类
			$rs=$pd->query("select id,name from subjecter_article_type order by odx");
			echo json_encode($rs->fetchAll(PDO::FETCH_ASSOC));
			break;
			
		case "get_sys_subject":	## 学科分类
			$rs=$pd->query("select id,name from sys_subject where school=0 order by id");
			echo json_encode($rs->fetchAll(PDO::FETCH_ASSOC));
			break;
			
		case "exist_subject":	## 学科是否存在
			$name = $_POST["name"];
			$period = $_POST["period"];
			echo $pd->query("select count(1) from sys_subject where school=0 and period=".$period." and name='".$name."'")->fetchColumn(0);
			break;
			
		case "exist_grade":		## 年级是否存在
			$name = $_POST["name"];
			$period = $_POST["period"];
			echo $pd->query("select count(1) from sys_grade where period=".$period." and name='".$name."'")->fetchColumn(0);
			break;
			
		case "exist_book":		## 课本是否存在
			$title = $_POST["title"];
			$period = $_POST["period"];
			$subject = $_POST["subject"];
			$grade = $_POST["grade"];
			$edition = $_POST["edition"];
			$volume = $_POST["volume"];
			$year = $_POST["year"];
			$required = $_POST["required"];
			echo $pd->query("select count(1) from sys_textbook where title='".$title."' and period=".$period." and subject=".$subject." and grade=".$grade." and edition=".$edition." and volume=".$volume." and year=".$year." and required=".$required)->fetchColumn(0);
			break;
			
		case "exist_restype":	# 资源类型 是否存在
			$name = $_POST["name"];
			echo $pd->query("select count(1) from res_type where `name`='".$name."'")->fetchColumn(0);
			break;
			
		case "exist_edition":	# 版本是否存在
			$name = $_POST["name"];
			echo $pd->query("select count(1) from sys_textbook_edition where `name`='".$name."'")->fetchColumn(0);
			break;
			
		case "exist_volume":	# 版别是否存在
			$name = $_POST["name"];
			echo $pd->query("select count(1) from sys_textbook_volume where `name`='".$name."'")->fetchColumn(0);
			break;
			
		case "exist_chapter":	# 章 是否存在
			$title = $_POST["title"];
			$book = $_POST["book"];
			echo $pd->query("select count(1) from sys_books_chapters where parentid=0 and title='".$title."' and book=".$book)->fetchColumn(0);
			break;
			
		case "exist_part":	# 节 是否存在
			$title = $_POST["title"];
			$chapter = $_POST["chapter"];
			echo $pd->query("select count(1) from sys_books_chapters where parentid=".$chapter." and title='".$title."'")->fetchColumn(0);
			break;
			
		case "get_restype_name":	## 返回资源类型名称
			echo $pd->query("select `name` from res_type where `id`=".$_POST["id"])->fetchColumn(0);
			break;
			
		case "get_volume_name":	# 返回版别名称
			echo $pd->query("select `name` from sys_textbook_volume where `id`=".$_POST["id"])->fetchColumn(0);
			break;
			
		case "get_edition_name":	# 返回版本名称
			echo $pd->query("select `name` from sys_textbook_edition where `id`=".$_POST["id"])->fetchColumn(0);
			break;
			
		case "get_grade_name":	## 返回年级名称
			echo $pd->query("select CONCAT(`name`, ',', `period`) from sys_grade where `id`=".$_POST["id"])->fetchColumn(0);
			break;
			
		case "get_subject_name":	## 返回学科名称
			echo $pd->query("select CONCAT(`name`, ',', `period`) from sys_subject where school=0 and `id`=".$_POST["id"])->fetchColumn(0);
			break;
			
		case "get_book_name":	## 返回课本名称
			// 火车的故事,2,100,11,1,2,2015,1
			echo $pd->query("select CONCAT(`title`, ',', `period`, ',', subject, ',', grade, ',', edition, ',', volume, ',', year, ',', required) from sys_textbook where `id`=".$_POST["id"])->fetchColumn(0);
			break;
			
		case "get_chapter_name":	# 返回 章 信息
			echo $pd->query("select CONCAT(`title`, ',', `book`) from sys_books_chapters where parentid=0 and `id`=".$_POST["id"])->fetchColumn(0);
			break;
			
		case "get_part_name":	# 返回 节 信息
			echo $pd->query("select CONCAT(`title`, ',', `parentid`) from sys_books_chapters where parentid!=0 and `id`=".$_POST["id"])->fetchColumn(0);
			break;
			
		case "get_books":	# 返回所有课本
			$period = $_POST["period"];
			$subject = $_POST["subject"];
			$grade = $_POST["grade"];
			$edition = $_POST["edition"];
			$volume = $_POST["volume"];
			$year = $_POST["year"];
			$required = $_POST["required"];
			
			$srcSql = "";
			if($edition != "") {
				$srcSql .= " and `edition`=".$edition;
			}
			if($volume != "") {
				$srcSql .= " and `volume`=".$volume;
			}
			if($year != "") {
				$srcSql .= " and `year`=".$year;
			}
			if($required != "") {
				$srcSql .= " and `required`=".$required;
			}
			
			echo getBooks("sys_textbook where period=".$period." and subject=".$subject." and grade=".$grade.$srcSql, $pd);
			break;
			
		case "get_chapters":	# 返回课本的所有章
			$book = $_POST["book"];
			echo getChapters($book, "sys_books_chapters where book=".$book." and parentid=0", $pd);
			break;
			
		case "get_part_options":	# 返回某一章的所有节（select的option标签）
			$parentid = $_POST["chapter"];
			echo getParts($parentid, "sys_books_chapters where parentid=".$parentid, $pd);
			break;
			
		case "get_all_by_book_chapter_part":	# 用于option级联更新加载内容
			$period = $_POST["period"];
			$subject = $_POST["subject"];
			$grade = $_POST["grade"];
			$edition = $_POST["edition"];
			$volume = $_POST["volume"];
			$year = $_POST["year"];
			$required = $_POST["required"];
			$book = $_POST["book"];
			$chapter = $_POST["chapter"];
			
			$srcSql = "";
			if($edition != "") {
				$srcSql .= " and `edition`=".$edition;
			}
			if($volume != "") {
				$srcSql .= " and `volume`=".$volume;
			}
			if($year != "") {
				$srcSql .= " and `year`=".$year;
			}
			if($required != "") {
				$srcSql .= " and `required`=".$required;
			}
			
			$books = getBooks("sys_textbook where period=".$period." and subject=".$subject." and grade=".$grade.$srcSql, $pd);	// 课本
			
			$chapters = getChapters($book, "sys_books_chapters where book=".$book." and parentid=0", $pd);	// 章
			
			$parts = getParts($chapter, "sys_books_chapters where parentid=".$chapter, $pd);	// 节
			
			echo json_encode(array('books'=>$books, 'chapters'=>$chapters, 'parts'=>$parts));
			break;
			
		case "get_chapters_and_parts": # 返回所有章节
			$book = $_POST["book"];
			$title = $_POST["title"];
			
			$T=new pdo_template('../html/books_child.htm');
			$T->SetBlock2("chapters_list", "SELECT id,title,odx from sys_books_chapters where parentid=0 and book=".$book." order by odx",
				array(array("block"=>"parts_list", "pid"=>"id", "sql"=>"select id,title,odx from sys_books_chapters where parentid=? order by odx")));
			$T->Set("book_title", $title);
			
			$T->clearNaN();
			$T->clearNoN(); 
			$content = $T->content;
			$T->close();
			unset($T);
			
			echo !strpos($content, '</li>') ? '<div id="h_menuart"><h1 style="background-color:rgba(0,0,0,0.5);padding-left:10px;color:white;font-size:14px;"  onclick="hideMenu();">《'.$title.'》<span class="pull-right" style="padding-right:10px;">关闭</span></h1><h1><i>- </i>尚未添加章节</h1></div>' : $content;
			break;
			
		case "get_parts":	# 返回某一章的所有节
			$parentid = $_POST["parentid"];
			$title = $_POST["title"];
			
			$T=new pdo_template('../html/chapters_child.htm');
			$T->SetBlock("parts_list", "select id,title,odx from sys_books_chapters where parentid=$parentid order by odx");
			$T->Set("chapter_title", $title);
			
			$T->clearNaN();
			$T->clearNoN(); 
			$content = $T->content;
			$T->close();
			unset($T);
			
			echo !strpos($content, '</li>') ? '<div id="h_menuart"><h1 style="background-color:rgba(0,0,0,0.5);padding-left:10px;color:white;font-size:14px;" onclick="hideMenu();">'.$title.'<span class="pull-right" style="padding-right:10px;">关闭</span></h1><ul><li style="font-size:14px; font-weight:bold;"><i>- </i>尚未添加子节</li></ul></div>' : $content;
			break;
	}

	$pd->close();
	unset($pd);
	unset($rs);
	
	// 返回子节select标签内容
	function getParts($parentid, $tableName, $T) {
		if($parentid == "") { return '<option value="">—节—</option>'; }
		
		$html = '<option value="">—节—</option>';
		
		$result = $T->query("select id, title from ".$tableName." order by odx")->fetchAll(PDO::FETCH_ASSOC);
		
		foreach($result as $row) {
			$html .= "<option value='".$row['id']."'>".$row['title']."</option>";
		}
		
		return $html;
	}
	
	// 返回章节select标签内容
	function getChapters($book, $tableName, $T) {
		
		if($book == "") { return '<option value="">—章—</option>'; }
		
		$html = '<option value="">—章—</option>';
		
		$result = $T->query("select id, title from ".$tableName." order by odx")->fetchAll(PDO::FETCH_ASSOC);
		
		foreach($result as $row) {
			$html .= "<option value='".$row['id']."'>".$row['title']."</option>";
		}
		
		return $html;
	}
	
	// 返回课本select标签内容
	function getBooks($tableName, $T) {
		$html = '<option value="">—课本—</option>';
		
		$result = $T->query("select id, title from ".$tableName." order by odx")->fetchAll(PDO::FETCH_ASSOC);
		
		foreach($result as $row) {
			$html .= "<option value='".$row['id']."'>课本：《".$row['title']."》</option>";
		}
		
		return $html;
	}
	
	// 返回年级select标签内容
	function fillOpts($tableName, $defaultName, $T) { 
		$html = '<option value="">'.$defaultName."</option>";
		
		$result = $T->query("select id, name from ".$tableName." order by odx")->fetchAll(PDO::FETCH_ASSOC);
		
		foreach($result as $row) {
			$html .= "<option value='".$row['id']."'>".$row['name']."</option>";
		}
		
		return $html;
	}