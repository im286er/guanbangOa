<?php
	require_once '../../ppf/pdo_mysql.php';
	
	# ��ѧ����������Ϣ
	function block_bind_by_period($tag, $T) {
		$T->SetBlock($tag, getQueryPeriodSql());
	}
		
	# ���ز�ѯ����ѧ�ε�sql
	function getQueryPeriodSql($display=1) {
		$sql = $display == 1 ? " where display=1 " : "";
		return "select * from `sys_period` ".$sql." order by odx";
	}
	
	# ����ѧ��������
	function initPeriodOptions($tag, $title, $T) {
		$T->Set($tag, getOptions("sys_period where display=1 ", $title, $T));
	}
	
	# ������������
	function getAllArticles($T, $srcSql, $currentPage, $pagesize) {
		$sql = "select t1.*, t2.name as typename, t3.truename, t4.name as subname, t4.period, t5.name as schoolname from subjecter_articles t1 ";
		$sql .= " left join subjecter_article_type t2 on t2.id=t1.typeid";
		$sql .= " left join act_member t3 on t3.id=t1.uid ";
		$sql .= " left join sys_subject t4 on t4.id=t1.subject";
		$sql .= " left join school t5 on t5.id=t3.school";
		$sql .= " left join sys_period t6 on t6.id=t1.period";
		$sql .= " where t1.id>=0 and t6.display=1 and t4.school=0".$srcSql;
		$sql .= " order by t1.postdate desc limit ".(($currentPage - 1) * $pagesize).", $pagesize";
		$T->SetBlock("list", $sql);
	}
	
	# �����������¼�¼����
	function getAllArticlesCount($T, $srcSql) {
		// �����ѯ������ѧ���Ƿ�����
		return $T->db->query(
		@"select count(1) from `subjecter_articles` t1 
		left join sys_period t6 on t6.id=t1.period 
		left join sys_subject t4 on t4.id=t1.subject 
		where t1.id>=0 ".$srcSql." and t6.display=1 and t4.school=0")->fetchColumn(0);
	}
	
	# ����ǰ��ģ������
	function get_tplName() {
		$pd = new pdo_mysql();
		$tmp = $pd->query('select template from subjecter where parentid=0')->fetchColumn(0);
		$pd->close();
		unset($pd);
		return $tmp;
	}
	
	# �������·���������
	function initArticleSelect($subject, $title, $T) {
		return $T->Set("sel_typeid", getOptions("subjecter_article_type where subject=$subject", $title, $T));
	}
	
	# Ԥ������ѧ�ι�����ѧ�����ݣ�school=0��
	function initSubjects($T) {
		$T->SetBlock2("hide_subjects", getQueryPeriodSql(1),
			array(array("block"=>"hide_subjects_rp", "pid"=>"id", "sql"=>"select id, name from sys_subject where school=0 and period=? order by odx")));
	}
	
	# Ԥ������ѧ�ι������꼶����
	function initGrades($T) {
		$T->SetBlock2("hide_grades", getQueryPeriodSql(1),
			array(array("block"=>"hide_grades_rp", "pid"=>"id", "sql"=>"select id, name from sys_grade where period=?")));
	}
	
	# ѧ���������ʼ��
	function initPeriodSelect($T) {
		$T->SetBlock("list_period", "SELECT * from sys_period where display=1 order by odx");
	}
	
	function initEditionSelect($T) {
		$T->SetBlock("list_edition", "SELECT * from sys_textbook_edition order by odx");
	}
	
	function initVolumeSelect($T) {
		$T->SetBlock("list_volume", "SELECT * from sys_textbook_volume order by odx");
	}
	
	function initYearOptions($T) {
		$minYear = $T->query("select min(year) from `sys_textbook`")->fetchColumn(0);
		$yearOpts = fillYear($minYear);
		return $yearOpts;
	}
	
	# PHPȥ���ַ����е����пո񼰻���
	function trimall($str){
		//$str = trim($str);
		//$str = preg_replace('/[\s��]/', '', $str);
		return str_replace(array(" ","��","\t","\n","\r"), '', $str);
	}
	
	# ��select����������<select>�汾
	function getOptions($tableName, $defaultName, $T) {
		$html = '<option value="">'.$defaultName."</option>";
		
		$result = $T->query("select id, name from ".$tableName." order by odx")->fetchAll(PDO::FETCH_ASSOC);
		
		foreach($result as $row) {
			$html .= "<option value='".$row['id']."'>".$row['name']."</option>";
		}
		
		return $html;
	}
	
	# ��select����������<select>�汾
	function getOptionsWithNoTitle($tableName, $id, $name, $prefix, $suffix, $T) {
		$html = '';
		
		$result = $T->query("select `$id`, `$name` from ".$tableName." order by odx")->fetchAll(PDO::FETCH_ASSOC);
		
		foreach($result as $row) {
			$html .= "<option value='".$row[$id]."'>".$prefix.$row[$name].$suffix."</option>";
		}
		
		return $html;
	}
	
	# ��select����������<li>�汾
	function getLiItems($tableName, $T) {
		$html = "";
		$result = $T->query("select id, name from ".$tableName." order by id")->fetchAll(PDO::FETCH_ASSOC);
		
		foreach($result as $row) {
			$html .= "<li><a onclick='doLiSelect(this);' value='".$row['id']."'>".$row['name']."</a></li>";
		}
		
		return $html;
	}
	
	# ��select����������<li>ѧ�ΰ汾
	function getPGradeLiItems($tableName, $T) {
		$html = "";
		$result = $T->query("select id, name,periods from ".$tableName." order by id")->fetchAll(PDO::FETCH_ASSOC);
		
		foreach($result as $row) {
			$html .= "<li><a onclick='doLiSelect(this);' value='".$row['id']."'>".$row['periods'].$row['name']."</a></li>";
		}
		
		return $html;
	}
	
	# �����꼶ѧ��sys_grade����������html����<li>�汾���ѷϳ���
	function getGradeLiItems($tableName, $T) {
		$html = "";
		
		$result = $T->query("SELECT id,name,periods,period FROM `sys_grade` order by period,id")->fetchAll(PDO::FETCH_ASSOC);
		
		$labelList = array();	// <optgroup label>����
		for($i = 0; $i < count($result); $i++) {
			if (  !in_array(array($result[$i]['period'], $result[$i]['periods']), $labelList) ) {
				$labelList[] = array($result[$i]['period'], $result[$i]['periods']);
			}
		}
		
		for($i = 0; $i < count($labelList); $i++) {
			$html .= "<li class='dropdown-header' value='".$labelList[$i][0]."'>----".$labelList[$i][1]."----</li>";
			
			for($j = 0; $j < count($result); $j++) {
				if( $result[$j]["period"] ==  $labelList[$i][0] ) {
					$html .= "<li><a onclick='doLiSelect(this);' data-period='".$result[$j]["period"]."' value='".$result[$j]["id"]."'>".$result[$j]["name"]."</a></li>";
				}
			}
		}
		
		return $html;
	}
	
	# �����꼶ѧ��sys_grade����������html����<select>�汾
	function getGradeOptions($tableName, $defaultName, $T) {
		$html = '<option value="">'.$defaultName."</option>";
		
		$result = $T->query("SELECT id,name,periods,period FROM `sys_grade` order by period,id")->fetchAll(PDO::FETCH_ASSOC);
		
		$labelList = array();	// <optgroup label>����
		for($i = 0; $i < count($result); $i++) {
			if (  !in_array(array($result[$i]['period'], $result[$i]['periods']), $labelList) ) {
				$labelList[] = array($result[$i]['period'], $result[$i]['periods']);
			}
		}
		
		for($i = 0; $i < count($labelList); $i++) {
			$html .= "<optgroup label='".$labelList[$i][1]."' value='".$labelList[$i][0]."'>";
			
			for($j = 0; $j < count($result); $j++) {
				if( $result[$j]["period"] ==  $labelList[$i][0] ) {
					$html .= "<option value='".$result[$j]["id"]."' data-period='".$result[$j]["period"]."'>";
					$html .= $result[$j]["name"];
					$html .= "</option>";
				}
			}
			$html .= "</optgroup>";
		}
		
		return $html;
	}
	
	# ��̨PHP����js��escape��ǰ̨��ѯ�ַ���������ʹ��escape(string)��ǰ̨��ȡ�ַ���ʹ��unescape(string)
	// function unescape($str)
	// {
		// $ret = '';
		// $len = strlen($str);
		// for ($i = 0; $i < $len; $i ++)
		// {
			// if ($str[$i] == '%' && $str[$i + 1] == 'u')
			// {
				// $val = hexdec(substr($str, $i + 2, 4));
				// if ($val < 0x7f)
					// $ret .= chr($val);
				// else 
					// if ($val < 0x800)
						// $ret .= chr(0xc0 | ($val >> 6)) .
						 // chr(0x80 | ($val & 0x3f));
					// else
						// $ret .= chr(0xe0 | ($val >> 12)) .
						 // chr(0x80 | (($val >> 6) & 0x3f)) .
						 // chr(0x80 | ($val & 0x3f));
				// $i += 5;
			// } else 
				// if ($str[$i] == '%')
				// {
					// $ret .= urldecode(substr($str, $i, 3));
					// $i += 2;
				// } else
					// $ret .= $str[$i];
		// }
		// return $ret;
	// }	
	
	/**
	 * js escape php ʵ�֣�δ��ʹ�ã�
	 * @param $string           the sting want to be escaped
	 * @param $in_encoding      
	 * @param $out_encoding     
	 */
	// function escape($string, $in_encoding = 'UTF-8',$out_encoding = 'UCS-2') {
		// $return = '';
		// if (function_exists('mb_get_info')) {
			// for($x = 0; $x < mb_strlen ( $string, $in_encoding ); $x ++) {
				// $str = mb_substr ( $string, $x, 1, $in_encoding );
				// if (strlen ( $str ) > 1) { // ���ֽ��ַ�
					// $return .= '%u' . strtoupper ( bin2hex ( mb_convert_encoding ( $str, $out_encoding, $in_encoding ) ) );
				// } else {
					// $return .= '%' . strtoupper ( bin2hex ( $str ) );
				// }
			// }
		// }
		// return $return;
	// }
	
	# ����ĳһĿ¼�µ�����Ŀ¼
	function get_all_dir ( $dir, $excepte_dir_name )
    {
        $result = array();
		$i = 0;
        $handle = opendir($dir);
        if ( $handle )
        {
			readdir($handle);
			readdir($handle);
            while ( ($file = readdir($handle)) !== false )
            {
                if ( $file != $excepte_dir_name) {
					$result[$i] = $file;
					$i = $i + 1;
				}
            }
            closedir($handle);
        }
        return $result;
    }
	
	# ��ʾģ��Ԥ��
	function showTemplates($templates) {
		$html = '';
		foreach($templates as $dir_name) {
			$html .= '<td align="center" style="border:0px;" onmouseover="movein(this);" onmouseout="moveout(this);"><a onclick="choose('.$dir_name.');"><img id="img'.$dir_name.'" class="img-thumbnail" src="../html/'.$dir_name.'/index.jpg" width="200px" /></a></td>';
		}
		return $html;
	}
	
	# ��ʾģ��radio��ǩ
	function showTmpRadios($templates, $tplName) {
		$html = '';
		foreach($templates as $dir_name) {
			$html .= '<td align="center"><input onclick="choose('.$dir_name.');" id="rdo'.$dir_name.'" type="radio" name="rdo_templates" value="'.$dir_name.'" '.($dir_name == $tplName ? 'checked="checked"' : '').' /> <span id="span'.$dir_name.'">'.($dir_name == $tplName ? '��ǰģ��' : '').'</span></td>';
		}
		return $html;
	}
	
	# �������ݿ����С��ݣ������������ݣ����ֵΪ��ǰ���
	function fillYear($minYear) {
		$curYear = date('Y');
		$html = "";
		
		for($i = $curYear; $i >= $minYear; $i--) {
			$html .= "<option value='".$i."'>".$i."</option>";
		}
		
		return $html;
	}
	
	# �������ݿ����С��ݣ������������ݣ����ֵΪ��ǰ���
	function fillYearAdd($minYear) {
		$curYear = date('Y');
		$html = "";
		
		for($i = $curYear; $i >= $minYear; $i--) {
			if($i == $curYear) {
				$html .= "<option value='".$i."' selected='selected'>".$i."</option>";
			} else {
				$html .= "<option value='".$i."'>".$i."</option>";
			}
		}
		
		return $html;
	}
	
	# �������пα�
	function getBooksOptions($user_period, $user_subject, $T) {
		$html = '';
		$sql = "select A.id, A.title from sys_textbook A";
		$sql .= " where A.period=".$user_period;
		$sql .= " and A.subject=".$user_subject;
		$sql .= " and A.grade=".$_GET["gra"];
		
		if(!empty($_GET["edi"])) {
			$sql .= " and A.edition=".$_GET["edi"];
		}
		if(!empty($_GET["vol"])) {
			$sql .= " and A.volume=".$_GET["vol"];
		}
		if(!empty($_GET["yea"])) {
			$sql .= " and A.year=".$_GET["yea"];
		}
		if(!empty($_GET["req"])) {
			$sql .= " and A.required=".$_GET["req"];
		}
		
		$sql .= " order by A.odx";
		
		$result = $T->query($sql)->fetchAll(PDO::FETCH_ASSOC);
		
		foreach($result as $row) {
			$html .= "<option value='".$row['id']."'>�α�����".$row['title']."��</option>";
		}
		
		return $html;
	}
	
	# ����������
	function getChaptersCount($srcSql, $T) {
		return $T->db->query(
		@"select count(1) from `sys_books_chapters` C 
		left join sys_textbook B on B.id=C.book 
		left join sys_period P on P.id=B.period 
		left join sys_subject S on S.id=B.subject 
		left join sys_grade G on G.id=B.grade 
		left join sys_textbook_edition E on E.id=B.edition 
		left join sys_textbook_volume V on V.id=B.volume 
		where C.parentid=0 and P.display=1".$srcSql)->fetchColumn(0);
	}
	
	# ���ؽ�����
	function getPartsCount($srcSql, $T) {
		return $T->db->query(
		@"select count(1) from `sys_books_chapters` C 
		left join sys_textbook B on B.id=C.book 
		left join sys_period P on P.id=B.period 
		left join sys_subject S on S.id=B.subject 
		left join sys_grade G on G.id=B.grade 
		left join sys_textbook_edition E on E.id=B.edition 
		left join sys_textbook_volume V on V.id=B.volume 
		where C.parentid!=0 and P.display=1".$srcSql)->fetchColumn(0);
	}
	
	# �����½�select��ǩ����
	function getChapters($sql, $T) {
		$html = '';
		
		$result = $T->query($sql)->fetchAll(PDO::FETCH_ASSOC);
		
		foreach($result as $row) {
			$html .= "<option value='".$row['id']."'>".$row['title']."</option>";
		}
		
		return $html;
	}
	
	# ������Դ����
	function initResTypeSelect($tag, $T) {
		$T->SetBlock($tag, "select `id`, `name` from res_type order by odx");
	}
	
	# ���ز�ѯ������sql��䣬���������ʽΪ �ֶ���=>����ֵ
	function getSearchSql($alias, $searchArray) {
		$srcSql = "";
		
		foreach ($searchArray as $key=>$value) {
			if($value != "") {
				if($key == 'title') {
					$srcSql .= " and {0}.`".$key."` like '%".$value."%'";
				} else {
					$srcSql .= " and {0}.`".$key."`=".$value;
				}
			}
		}
		
		return str_replace('{0}', $alias, $srcSql);
	}
	
	# �������ص�ѧ�ơ��꼶�������ǩ�����棩
	function get_subject_and_grade_cachefile() {
		
		if(!file_exists('html/subject_and_grade_cache.htm')) {
			
			$T = new pdo_template('html/tpl_subject_and_grade.htm');
			$content = "";
			
			initSubjects($T);
			initGrades($T);
			
			//�������ֱ�ǩ������滻
			//$T->clearNaN();
			//$T->clearNoN(); 
			$content = $T->content;
			
			$T->close();
			unset($T);
			
			file_put_contents('html/subject_and_grade_cache.htm', $content);
		}
		return 'html/subject_and_grade_cache.htm';
	}
	
	function init_edit_page($id, $T) {
		// ����idȡperiod, book, chapter, part
		// ��subject��grade {init_grade}����Ĭ��option��ǩ getOptions($tableName, $defaultName, $T
		// ��book, chapter, part {init_book}����Ĭ��option��ǩ getOptions($tableName, $defaultName, $T
		// ����Դlogo
		
		$data = $T->db->query("SELECT period, subject, grade, book, chapter, part, edition, volume, year, required FROM `subjecter_resources` where `id`=$id")->fetchAll(PDO::FETCH_ASSOC);
		
		$searchArray = array();
		$period = "";
		$book = "";
		$chapter = "";
		foreach($data as $row) {
			if($row['period'] != null) { $period = $searchArray['period'] = $row['period']; }
			if($row['subject'] != null) $searchArray['subject']=$row['subject'];
			if($row['grade'] != null) $searchArray['grade']=$row['grade'];
			
			if($row['book'] != null)  { $book = $row['book']; }
			if($row['chapter'] != null)  { $chapter = $row['chapter']; }
			
			if($row['edition'] != null) $searchArray['edition']=$row['edition'];
			if($row['volume'] != null) $searchArray['volume']=$row['volume'];
			if($row['year'] != null) $searchArray['year']=$row['year'];
			if($row['required'] != null) $searchArray['required']=$row['required'];
		}
		$srcSql = getSearchSql('B', $searchArray);
		
		$T->Set('init_subject', getOptionsWithNoTitle("sys_subject where period=$period", 'id', 'name', '', '', $T));
		$T->Set('init_grade', getOptionsWithNoTitle("sys_grade where period=$period", 'id', 'name', '', '', $T));
		$T->Set('init_book', getOptionsWithNoTitle("sys_textbook B where B.id>0 ".$srcSql, 'id', 'title', '�α�����', '��', $T));
		
		if($book != "") {
			$T->Set('init_chapter', getOptionsWithNoTitle("sys_books_chapters where parentid=0 and book=$book", 'id', 'title', '', '', $T));
		}
		
		if($chapter != "") {
			$T->Set('init_part', getOptionsWithNoTitle("sys_books_chapters where parentid=$chapter", 'id', 'title', '', '', $T));
		}
	}