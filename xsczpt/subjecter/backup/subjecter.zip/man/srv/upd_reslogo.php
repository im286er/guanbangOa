<?php 
header("Content-type: text/html; charset=utf8;");
require '../../../cfg/config.inc';
require '../../../ppf/pdo_mysql.php';

# 上传幻灯片
$pd = new pdo_mysql();

foreach($_FILES as $f){
	$id = $_POST["id"];
	$hasfile = $f["error"] > 0 ? false : true;	// 是否选择了要上传的图片
	
	if( !$hasfile) {
		echo '{"ret":"err", "des":"上传图片出错，请选择图片！"}';
		exit;
	}
	
	if ( $hasfile ) {
		$fsize = $f["size"];				// ($f["size"] / 1024) . kb;
		$ftmp_name = $f["tmp_name"];		// 临时文件位置  $_files["file"]["tmp_name"];
		$ftype = $f["type"];				// 文件类型 $_files["file"]["type"]
		$fname = $f["name"];  				// 原始文件名 $_files["file"]["name"]

		$fext = ".".strtolower(pathinfo($fname, PATHINFO_EXTENSION));	// .jpg
		
		if(!strpos(" .jpg.gif.png", $fext)){
			echo '{"ret":"err", "des":"禁止上传的文件类型！"}';
			exit;
		}
		if($fsize > 204800){
			echo '{"ret":"err", "des":"上传的图片大小超过200K！"}';
			exit;
		}
	}

	$pic_path = '/upds/subjecter/img/reslogo/';
	
	if(!is_dir('../../../'.$pic_path))
	{
		mkdir('../../../'.$pic_path);
	}
	$pic_fullpath = DIR_ROOT.$pic_path;	// 返回C:/xampp/htdocs/pkedu/upds/subjecter/img/reslogo/
	
	# 保存图片 
	if (move_uploaded_file($ftmp_name, $pic_fullpath.$id.$fext)){
		# 更新数据库表中的pic字段
		$pd->exec("update `subjecter_resources` set `pic`='".$id.$fext."' where id=".$id);
		echo '{"ret":"ok", "fname":"'.$id.$fext.'", "des":"上传成功！"}';
	}
}

# 释放资源
$pd->close();
unset($pd);
unset($result);